﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fmrNQFHours
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnHPW = New System.Windows.Forms.Button()
        Me.lblNCr = New System.Windows.Forms.Label()
        Me.lblDWs = New System.Windows.Forms.Label()
        Me.lblTHrs = New System.Windows.Forms.Label()
        Me.lblHPW = New System.Windows.Forms.Label()
        Me.txtNCr = New System.Windows.Forms.TextBox()
        Me.txtDWs = New System.Windows.Forms.TextBox()
        Me.txtTHrs = New System.Windows.Forms.TextBox()
        Me.txtHPW = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnHPW
        '
        Me.btnHPW.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.btnHPW.Location = New System.Drawing.Point(330, 15)
        Me.btnHPW.Name = "btnHPW"
        Me.btnHPW.Size = New System.Drawing.Size(165, 155)
        Me.btnHPW.TabIndex = 1
        Me.btnHPW.Text = "Calculate"
        Me.btnHPW.UseVisualStyleBackColor = True
        '
        'lblNCr
        '
        Me.lblNCr.AutoSize = True
        Me.lblNCr.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblNCr.Location = New System.Drawing.Point(59, 18)
        Me.lblNCr.Name = "lblNCr"
        Me.lblNCr.Size = New System.Drawing.Size(121, 25)
        Me.lblNCr.TabIndex = 2
        Me.lblNCr.Text = "NQF Credits"
        '
        'lblDWs
        '
        Me.lblDWs.AutoSize = True
        Me.lblDWs.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblDWs.Location = New System.Drawing.Point(20, 143)
        Me.lblDWs.Name = "lblDWs"
        Me.lblDWs.Size = New System.Drawing.Size(160, 25)
        Me.lblDWs.TabIndex = 4
        Me.lblDWs.Text = "Duration (weeks)"
        '
        'lblTHrs
        '
        Me.lblTHrs.AutoSize = True
        Me.lblTHrs.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblTHrs.Location = New System.Drawing.Point(549, 10)
        Me.lblTHrs.Name = "lblTHrs"
        Me.lblTHrs.Size = New System.Drawing.Size(113, 25)
        Me.lblTHrs.TabIndex = 5
        Me.lblTHrs.Text = "Total Hours"
        '
        'lblHPW
        '
        Me.lblHPW.AutoSize = True
        Me.lblHPW.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblHPW.Location = New System.Drawing.Point(528, 102)
        Me.lblHPW.Name = "lblHPW"
        Me.lblHPW.Size = New System.Drawing.Size(154, 25)
        Me.lblHPW.TabIndex = 6
        Me.lblHPW.Text = "Hours per Week"
        '
        'txtNCr
        '
        Me.txtNCr.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtNCr.Location = New System.Drawing.Point(186, 15)
        Me.txtNCr.Name = "txtNCr"
        Me.txtNCr.Size = New System.Drawing.Size(100, 30)
        Me.txtNCr.TabIndex = 7
        '
        'txtDWs
        '
        Me.txtDWs.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtDWs.Location = New System.Drawing.Point(186, 140)
        Me.txtDWs.Name = "txtDWs"
        Me.txtDWs.Size = New System.Drawing.Size(100, 30)
        Me.txtDWs.TabIndex = 9
        '
        'txtTHrs
        '
        Me.txtTHrs.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtTHrs.Location = New System.Drawing.Point(554, 38)
        Me.txtTHrs.Name = "txtTHrs"
        Me.txtTHrs.ReadOnly = True
        Me.txtTHrs.Size = New System.Drawing.Size(100, 30)
        Me.txtTHrs.TabIndex = 10
        '
        'txtHPW
        '
        Me.txtHPW.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtHPW.Location = New System.Drawing.Point(554, 130)
        Me.txtHPW.Name = "txtHPW"
        Me.txtHPW.ReadOnly = True
        Me.txtHPW.Size = New System.Drawing.Size(100, 30)
        Me.txtHPW.TabIndex = 11
        '
        'fmrNQFHours
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(733, 221)
        Me.Controls.Add(Me.txtHPW)
        Me.Controls.Add(Me.txtTHrs)
        Me.Controls.Add(Me.txtDWs)
        Me.Controls.Add(Me.txtNCr)
        Me.Controls.Add(Me.lblHPW)
        Me.Controls.Add(Me.lblTHrs)
        Me.Controls.Add(Me.lblDWs)
        Me.Controls.Add(Me.lblNCr)
        Me.Controls.Add(Me.btnHPW)
        Me.Name = "fmrNQFHours"
        Me.Text = "NQF Hours calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnHPW As Button
    Friend WithEvents lblNCr As Label
    Friend WithEvents lblDWs As Label
    Friend WithEvents lblTHrs As Label
    Friend WithEvents lblHPW As Label
    Friend WithEvents txtNCr As TextBox
    Friend WithEvents txtDWs As TextBox
    Friend WithEvents txtTHrs As TextBox
    Friend WithEvents txtHPW As TextBox
End Class
