﻿' ****************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022A-01
' Class name: frmNQFHours
' ****************************************************************************

Option Strict On
Option Explicit On

Public Class fmrNQFHours

    'First declare all variables

    Private NCr, DWs As Integer
    Private THrs As Integer
    Private HPW As Double

    Private Sub btnHPW_Click(sender As Object, e As EventArgs) Handles btnHPW.Click

        'This is what happens after the button is pressed
        'Get values from user
        'Associate user input with variables

        NCr = CInt(txtNCr.Text)
        DWs = CInt(txtDWs.Text)

        'Calculate Total hours and show them to the user

        THrs = NCr * 10

        txtTHrs.Text = CStr(THrs)

        'Calculate Hours per week and show them to the user

        HPW = THrs / DWs

        txtHPW.Text = CStr(HPW)

    End Sub
End Class
