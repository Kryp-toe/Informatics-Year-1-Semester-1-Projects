﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAllowTrack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdAllowTrack = New UJGrid.UJGrid()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnWith = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdAllowTrack
        '
        Me.grdAllowTrack.Cols = 4
        Me.grdAllowTrack.FixedCols = 1
        Me.grdAllowTrack.FixedRows = 1
        Me.grdAllowTrack.Location = New System.Drawing.Point(43, 76)
        Me.grdAllowTrack.Name = "grdAllowTrack"
        Me.grdAllowTrack.Rows = 7
        Me.grdAllowTrack.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdAllowTrack.Size = New System.Drawing.Size(404, 174)
        Me.grdAllowTrack.TabIndex = 0
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(97, 19)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(94, 51)
        Me.btnInitial.TabIndex = 1
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnWith
        '
        Me.btnWith.Location = New System.Drawing.Point(297, 19)
        Me.btnWith.Name = "btnWith"
        Me.btnWith.Size = New System.Drawing.Size(94, 51)
        Me.btnWith.TabIndex = 2
        Me.btnWith.Text = "Withdraw"
        Me.btnWith.UseVisualStyleBackColor = True
        '
        'frmAllowTrack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 390)
        Me.Controls.Add(Me.btnWith)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.grdAllowTrack)
        Me.Name = "frmAllowTrack"
        Me.Text = "Allowance Tracker"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdAllowTrack As UJGrid.UJGrid
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnWith As Button
End Class
