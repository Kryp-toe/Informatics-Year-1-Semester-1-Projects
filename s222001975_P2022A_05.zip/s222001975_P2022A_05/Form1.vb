﻿' ****************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022A-05
' Class name: frmAllowTrack
' ****************************************************************************

Option Strict On
Option Explicit On
Option Infer Off
Public Class frmAllowTrack

    'Declare VAriables
    Private OpenBal As Double
    Private EndBal As Double
    Private WithDraw(5) As Double
    Private NumTransWith As Integer
    Private CountWith As Integer
    Private AvgSpent As Double

    'Creat subroutines for specifying the number of rows and columns in the grid
    Private Sub GridConfig(ByVal Rs As Integer, ByVal Cs As Integer)

        grdAllowTrack.Rows = Rs
        grdAllowTrack.Cols = Cs

    End Sub
    Private Sub GridDisp(ByVal r As Integer, ByVal c As Integer, ByVal t As String)

        grdAllowTrack.Row = r
        grdAllowTrack.Col = c
        grdAllowTrack.Text = t

    End Sub
    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get initial allowance from user
        OpenBal = CDbl(InputBox("Please enter your initial allowance"))

        'Initialize amounts and program
        EndBal = 0
        AvgSpent = 0
        NumTransWith = 4
        CountWith = 0
        WithDraw(1) = 0
        WithDraw(2) = 0
        WithDraw(4) = 0
        WithDraw(3) = 0
        WithDraw(5) = 0
        GridDisp(1, 2, "R" & CStr(OpenBal))

    End Sub

    Private Sub btnWith_Click(sender As Object, e As EventArgs) Handles btnWith.Click

        'Show the user the initial balance
        EndBal = OpenBal

        'Allow code to run until all transactions are complete
        For CountWith = 1 To NumTransWith Step +1

            If EndBal > 0 Then

                'Get withdrawl amount from user and display
                WithDraw(CountWith) = CInt(InputBox("Insert amount spent in week " & CStr(CountWith)))
                GridDisp(CountWith + 1, 1, "-R " & CStr(WithDraw(CountWith)))

                'Calculate totals and display to user
                WithDraw(5) = WithDraw(1) + WithDraw(2) + WithDraw(3) + WithDraw(4)
                EndBal = OpenBal - WithDraw(5)
                GridDisp(NumTransWith + 2, 1, "-R" & CStr(WithDraw(5)))
                GridDisp(NumTransWith + 2, 2, "R" & CStr(EndBal))

                'Tell the user their average spent
                AvgSpent = WithDraw(5) / CountWith
                GridDisp(CountWith + 1, 3, "R" & CStr(AvgSpent))

                'Warn user when bal is below 50
                If EndBal <= 50 Then

                    MsgBox("Warning, your balance is currently R" & EndBal)

                End If

                'Do not allow transactions if bal is 0
            Else

                MsgBox("Your current balance is R" & EndBal & ". No more withdrawls are allowed")
                CountWith = NumTransWith

            End If

        Next CountWith

    End Sub

    Private Sub frmAllowTrack_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Set up the UJ Grid
        GridConfig(7, 4)
        GridDisp(0, 2, "Balance")
        GridDisp(0, 1, "Withdraw(-)")
        GridDisp(0, 3, "Average spent")
        GridDisp(0, 0, "Week no.")

        'Tell the week numbers
        GridDisp(2, 0, "Week 1")
        GridDisp(3, 0, "Week 2")
        GridDisp(4, 0, "Week 3")
        GridDisp(5, 0, "Week 4")

    End Sub
End Class
