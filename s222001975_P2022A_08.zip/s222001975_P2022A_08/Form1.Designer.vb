﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEastEggSale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnCaptData = New System.Windows.Forms.Button()
        Me.btnEditData = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnMax = New System.Windows.Forms.Button()
        Me.grdEastEgg = New UJGrid.UJGrid()
        Me.SuspendLayout()
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(21, 22)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(93, 56)
        Me.btnInitial.TabIndex = 0
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnCaptData
        '
        Me.btnCaptData.Location = New System.Drawing.Point(177, 22)
        Me.btnCaptData.Name = "btnCaptData"
        Me.btnCaptData.Size = New System.Drawing.Size(93, 56)
        Me.btnCaptData.TabIndex = 1
        Me.btnCaptData.Text = "Capture Data"
        Me.btnCaptData.UseVisualStyleBackColor = True
        '
        'btnEditData
        '
        Me.btnEditData.Location = New System.Drawing.Point(327, 22)
        Me.btnEditData.Name = "btnEditData"
        Me.btnEditData.Size = New System.Drawing.Size(93, 56)
        Me.btnEditData.TabIndex = 2
        Me.btnEditData.Text = "Edit Data"
        Me.btnEditData.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(474, 22)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(93, 56)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnMax
        '
        Me.btnMax.Location = New System.Drawing.Point(627, 22)
        Me.btnMax.Name = "btnMax"
        Me.btnMax.Size = New System.Drawing.Size(93, 56)
        Me.btnMax.TabIndex = 4
        Me.btnMax.Text = "Most Sold per Day"
        Me.btnMax.UseVisualStyleBackColor = True
        '
        'grdEastEgg
        '
        Me.grdEastEgg.Cols = 10
        Me.grdEastEgg.FixedCols = 1
        Me.grdEastEgg.FixedRows = 1
        Me.grdEastEgg.Location = New System.Drawing.Point(21, 84)
        Me.grdEastEgg.Name = "grdEastEgg"
        Me.grdEastEgg.Rows = 10
        Me.grdEastEgg.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdEastEgg.Size = New System.Drawing.Size(699, 241)
        Me.grdEastEgg.TabIndex = 5
        '
        'frmEastEggSale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(753, 372)
        Me.Controls.Add(Me.grdEastEgg)
        Me.Controls.Add(Me.btnMax)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.btnEditData)
        Me.Controls.Add(Me.btnCaptData)
        Me.Controls.Add(Me.btnInitial)
        Me.Name = "frmEastEggSale"
        Me.Text = "Easter Eggs Sales"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnInitial As Button
    Friend WithEvents btnCaptData As Button
    Friend WithEvents btnEditData As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnMax As Button
    Friend WithEvents grdEastEgg As UJGrid.UJGrid
End Class
