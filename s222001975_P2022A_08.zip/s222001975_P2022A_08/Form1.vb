﻿' ****************************************************************************
' Surname, Initials: Mayet, AA
' Student Number:222001975
' Practical: P2022A-08
' Class name: frmEastEggSale
' ****************************************************************************

Option Infer Off
Option Explicit On
Option Strict On

Public Class frmEastEggSale

    'Declare variables
    Private NumEggs(,) As Integer
    Private TotEggsShop() As Integer
    Private TotalEggsCalc As Integer
    Private AvgEggDay() As Double
    Private AvgEggsCalc As Double
    Private NumDay As Integer
    Private NumShop As Integer
    Private Max() As Integer
    Private DayEdit As Integer
    Private ShopEdit As Integer
    Private EggEdit As Integer

    'Make subroutines for grid
    Private Sub ConfigGrid(ByVal C As Integer, ByVal R As Integer)
        grdEastEgg.Cols = C
        grdEastEgg.Rows = R
    End Sub

    Private Sub DispGrid(ByRef c As Integer, ByRef r As Integer, ByRef t As String)
        grdEastEgg.Col = c
        grdEastEgg.Row = r
        grdEastEgg.Text = t
    End Sub

    'Make subroutine for calculating avg and total
    Private Function TotalCalc(ByVal s As Integer) As Integer

        Dim d As Integer

        For d = 1 To NumDay Step +1

            TotEggsShop(s) = TotEggsShop(s) + NumEggs(d, s)
        Next
        Return TotEggsShop(s)

    End Function

    Private Function AvgCalc(ByVal d As Integer) As Double

        Dim s As Integer
        Dim t As Integer
        t = 0

        For s = 1 To NumShop Step +1

            t += NumEggs(d, s)
            AvgEggDay(d) = t / NumShop

        Next
        Return AvgEggDay(d)

    End Function

    Private Sub frmEastEggSale_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Load Grid
        ConfigGrid(3, 3)
        DispGrid(0, 1, "Days")
        DispGrid(0, 2, "Total")
        DispGrid(1, 0, "Shops")
        DispGrid(2, 0, "Most Sold")

    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get num days and stores from user
        NumDay = CInt(InputBox("How many days are you recording?"))
        NumShop = CInt(InputBox("How many shops are you recording?"))

        'Size all variables
        ReDim NumEggs(NumDay, NumShop)
        ReDim TotEggsShop(NumShop)
        ReDim AvgEggDay(NumDay)
        ReDim Max(NumDay)

        'Initialize all variables
        TotalEggsCalc = 0
        AvgEggsCalc = 0
        DayEdit = 0
        ShopEdit = 0
        EggEdit = 0

        'Set up grid
        ConfigGrid(NumShop + 3, NumDay + 2)

        'Set up grid display
        Dim d As Integer
        For d = 1 To NumDay
            DispGrid(0, d, "Day " & d)
            DispGrid(0, d + 1, "Toatal")
        Next

        Dim s As Integer
        For s = 1 To NumShop
            DispGrid(s, 0, "Shop " & s)
            DispGrid(s + 1, 0, "Average")
            DispGrid(s + 2, 0, "Most Sold")
        Next

    End Sub

    Private Sub btnCaptData_Click(sender As Object, e As EventArgs) Handles btnCaptData.Click

        'Declare local variables
        Dim n As Integer
        Dim d As Integer
        Dim s As Integer

        'Get num of eggs per day/store and store in 2D array
        For d = 1 To NumDay Step +1

            For s = 1 To NumShop Step +1

                n = CInt(InputBox("How many eggs were sold on day " & d & " in shop " & s))
                NumEggs(d, s) = n
                DispGrid(s, d, CStr(n))

            Next

        Next

    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click

        'Get day/store/num eggs that user wants to edit
        DayEdit = CInt(InputBox("What day would you like to edit?"))
        ShopEdit = CInt(InputBox("What shop would you like to edit?"))
        EggEdit = CInt(InputBox("How many Eggs were sold on day " & DayEdit & " in Shop " & ShopEdit))

        'Place new numb in array
        NumEggs(DayEdit, ShopEdit) = EggEdit

        'Disp new value in grid
        DispGrid(ShopEdit, DayEdit, CStr(EggEdit))

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Declare local variables
        Dim s As Integer
        Dim d As Integer

        'Calc and disp total eggs
        For s = 1 To NumShop Step +1

            TotEggsShop(s) = 0

            TotalEggsCalc = TotalCalc(s)

            DispGrid(s, NumDay + 1, CStr(TotalEggsCalc))

        Next

        'Calc and disp avg eggs
        For d = 1 To NumDay Step +1

            AvgEggDay(d) = 0

            AvgEggsCalc = AvgCalc(d)

            DispGrid(NumShop + 1, d, CStr(AvgEggsCalc))

        Next

    End Sub

    Private Sub btnMax_Click(sender As Object, e As EventArgs) Handles btnMax.Click

        'Declare all local variables
        Dim d As Integer
        Dim s As Integer

        'Get the max num of eggs sold per day
        For d = 1 To NumDay Step +1

            Max(d) = NumEggs(d, 1)
            DispGrid(NumShop + 2, d, "Store 1")
            For s = 2 To NumShop Step +1

                If Max(d) < NumEggs(d, s) Then

                    Max(d) = NumEggs(d, s)
                    DispGrid(NumShop + 2, d, "Store " & s)

                End If

            Next

        Next

    End Sub

End Class