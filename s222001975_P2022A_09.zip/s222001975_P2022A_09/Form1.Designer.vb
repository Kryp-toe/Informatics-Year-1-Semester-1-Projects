﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMedVect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCaptData = New System.Windows.Forms.Button()
        Me.btnCalcTotAvg = New System.Windows.Forms.Button()
        Me.btnCalcPerc = New System.Windows.Forms.Button()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.btnFraud = New System.Windows.Forms.Button()
        Me.btnNeedHlp = New System.Windows.Forms.Button()
        Me.btnNumHelp = New System.Windows.Forms.Button()
        Me.txtNumFraud = New System.Windows.Forms.TextBox()
        Me.txtNameHelp = New System.Windows.Forms.TextBox()
        Me.txtNumHelp = New System.Windows.Forms.TextBox()
        Me.grdMedVect = New UJGrid.UJGrid()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblHelp = New System.Windows.Forms.Label()
        Me.lblNumbHelp = New System.Windows.Forms.Label()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnCaptData
        '
        Me.btnCaptData.Location = New System.Drawing.Point(129, 12)
        Me.btnCaptData.Name = "btnCaptData"
        Me.btnCaptData.Size = New System.Drawing.Size(75, 54)
        Me.btnCaptData.TabIndex = 0
        Me.btnCaptData.Text = "Capture Data"
        Me.btnCaptData.UseVisualStyleBackColor = True
        '
        'btnCalcTotAvg
        '
        Me.btnCalcTotAvg.Location = New System.Drawing.Point(231, 12)
        Me.btnCalcTotAvg.Name = "btnCalcTotAvg"
        Me.btnCalcTotAvg.Size = New System.Drawing.Size(75, 54)
        Me.btnCalcTotAvg.TabIndex = 1
        Me.btnCalcTotAvg.Text = "Calculate Total and Average "
        Me.btnCalcTotAvg.UseVisualStyleBackColor = True
        '
        'btnCalcPerc
        '
        Me.btnCalcPerc.Location = New System.Drawing.Point(332, 12)
        Me.btnCalcPerc.Name = "btnCalcPerc"
        Me.btnCalcPerc.Size = New System.Drawing.Size(75, 54)
        Me.btnCalcPerc.TabIndex = 2
        Me.btnCalcPerc.Text = "Calculate Percentage"
        Me.btnCalcPerc.UseVisualStyleBackColor = True
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(432, 12)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(75, 54)
        Me.btnRate.TabIndex = 3
        Me.btnRate.Text = "Rating"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'btnFraud
        '
        Me.btnFraud.Location = New System.Drawing.Point(331, 313)
        Me.btnFraud.Name = "btnFraud"
        Me.btnFraud.Size = New System.Drawing.Size(75, 36)
        Me.btnFraud.TabIndex = 4
        Me.btnFraud.Text = "Fraud"
        Me.btnFraud.UseVisualStyleBackColor = True
        '
        'btnNeedHlp
        '
        Me.btnNeedHlp.Location = New System.Drawing.Point(322, 359)
        Me.btnNeedHlp.Name = "btnNeedHlp"
        Me.btnNeedHlp.Size = New System.Drawing.Size(75, 36)
        Me.btnNeedHlp.TabIndex = 5
        Me.btnNeedHlp.Text = "Needs Help"
        Me.btnNeedHlp.UseVisualStyleBackColor = True
        '
        'btnNumHelp
        '
        Me.btnNumHelp.Location = New System.Drawing.Point(322, 406)
        Me.btnNumHelp.Name = "btnNumHelp"
        Me.btnNumHelp.Size = New System.Drawing.Size(75, 36)
        Me.btnNumHelp.TabIndex = 6
        Me.btnNumHelp.Text = "No. Regions to help"
        Me.btnNumHelp.UseVisualStyleBackColor = True
        '
        'txtNumFraud
        '
        Me.txtNumFraud.Location = New System.Drawing.Point(215, 316)
        Me.txtNumFraud.Name = "txtNumFraud"
        Me.txtNumFraud.Size = New System.Drawing.Size(100, 20)
        Me.txtNumFraud.TabIndex = 7
        '
        'txtNameHelp
        '
        Me.txtNameHelp.Location = New System.Drawing.Point(206, 362)
        Me.txtNameHelp.Name = "txtNameHelp"
        Me.txtNameHelp.Size = New System.Drawing.Size(100, 20)
        Me.txtNameHelp.TabIndex = 8
        '
        'txtNumHelp
        '
        Me.txtNumHelp.Location = New System.Drawing.Point(206, 409)
        Me.txtNumHelp.Name = "txtNumHelp"
        Me.txtNumHelp.Size = New System.Drawing.Size(100, 20)
        Me.txtNumHelp.TabIndex = 9
        '
        'grdMedVect
        '
        Me.grdMedVect.Cols = 6
        Me.grdMedVect.FixedCols = 1
        Me.grdMedVect.FixedRows = 1
        Me.grdMedVect.Location = New System.Drawing.Point(12, 72)
        Me.grdMedVect.Name = "grdMedVect"
        Me.grdMedVect.Rows = 8
        Me.grdMedVect.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdMedVect.Size = New System.Drawing.Size(506, 213)
        Me.grdMedVect.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 323)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Number of regions commiting Fraud"
        '
        'lblHelp
        '
        Me.lblHelp.AutoSize = True
        Me.lblHelp.Location = New System.Drawing.Point(61, 369)
        Me.lblHelp.Name = "lblHelp"
        Me.lblHelp.Size = New System.Drawing.Size(119, 13)
        Me.lblHelp.TabIndex = 12
        Me.lblHelp.Text = "Name of Region to help"
        '
        'lblNumbHelp
        '
        Me.lblNumbHelp.AutoSize = True
        Me.lblNumbHelp.Location = New System.Drawing.Point(52, 416)
        Me.lblNumbHelp.Name = "lblNumbHelp"
        Me.lblNumbHelp.Size = New System.Drawing.Size(128, 13)
        Me.lblNumbHelp.TabIndex = 13
        Me.lblNumbHelp.Text = "Number of regions to help"
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(28, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(75, 54)
        Me.btnInitial.TabIndex = 14
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'frmMedVect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 450)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.lblNumbHelp)
        Me.Controls.Add(Me.lblHelp)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grdMedVect)
        Me.Controls.Add(Me.txtNumHelp)
        Me.Controls.Add(Me.txtNameHelp)
        Me.Controls.Add(Me.txtNumFraud)
        Me.Controls.Add(Me.btnNumHelp)
        Me.Controls.Add(Me.btnNeedHlp)
        Me.Controls.Add(Me.btnFraud)
        Me.Controls.Add(Me.btnRate)
        Me.Controls.Add(Me.btnCalcPerc)
        Me.Controls.Add(Me.btnCalcTotAvg)
        Me.Controls.Add(Me.btnCaptData)
        Me.Name = "frmMedVect"
        Me.Text = "Medical Vector"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCaptData As Button
    Friend WithEvents btnCalcTotAvg As Button
    Friend WithEvents btnCalcPerc As Button
    Friend WithEvents btnRate As Button
    Friend WithEvents btnFraud As Button
    Friend WithEvents btnNeedHlp As Button
    Friend WithEvents btnNumHelp As Button
    Friend WithEvents txtNumFraud As TextBox
    Friend WithEvents txtNameHelp As TextBox
    Friend WithEvents txtNumHelp As TextBox
    Friend WithEvents grdMedVect As UJGrid.UJGrid
    Friend WithEvents Label1 As Label
    Friend WithEvents lblHelp As Label
    Friend WithEvents lblNumbHelp As Label
    Friend WithEvents btnInitial As Button
End Class
