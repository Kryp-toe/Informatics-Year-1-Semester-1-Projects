﻿' *****************************************************************
' ‘ Surname, Initials: Mayet, AA
' ‘ Student Number: 222001975
' ‘ Practical: P2022A-09
' ‘ Class name: frmMedVect
' ***************************************************************** 

Option Strict On
Option Explicit On
Option Infer Off

Public Class frmMedVect

    'Declare variables
    Private NumbRegion As Integer
    Private NumMonth As Integer
    Private Regions() As RegionsRec
    'Declare record
    Private Structure RegionsRec
        Public Name As String
        Public Population As Integer
        Public VaxedPM() As Integer
        Public TotPRegion As Integer
        Public AvgPRegion As Double
        Public PercVaxed As Double
        Public Rating As String
        Public Fraud As String
    End Structure
    Private NumFraud As Integer
    Private NeedsHlp As String
    Private NumHlp As Integer

    'Set up grid
    Private Sub MakeGrid(ByRef R As Integer, ByRef C As Integer)
        grdMedVect.Rows = R
        grdMedVect.Cols = C
    End Sub

    'Gird display
    Private Sub DispGrid(ByRef r As Integer, ByRef c As Integer, ByRef t As String)
        grdMedVect.Row = r
        grdMedVect.Col = c
        grdMedVect.Text = t
    End Sub

    'Set display
    Private Sub frmMedVect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MakeGrid(8, 5)
        DispGrid(0, 0, "Name")
        DispGrid(1, 0, "Population")
        DispGrid(2, 0, "No. Vaccines distributed")
        DispGrid(3, 0, "Total")
        DispGrid(4, 0, "Average")
        DispGrid(5, 0, "% of Vaccines Distributed")
        DispGrid(6, 0, "Rating")
        DispGrid(7, 0, "Fraud (Y/N)")
    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click
        'Get number of regions/months
        NumbRegion = CInt(InputBox("How many regions are you recording?"))
        NumMonth = CInt(InputBox("How many months are you recording?"))

        'Resize record
        ReDim Regions(NumbRegion)

        'Resize all arrays in record
        Dim count As Integer
        For count = 1 To NumbRegion
            ReDim Regions(count).VaxedPM(NumMonth)
        Next

        'Initialize variables
        NumHlp = 0
        NumFraud = 0
        NeedsHlp = ""

        'Set up grid
        MakeGrid(NumMonth + 7, NumbRegion + 1)

        'Set up display
        Dim r As Integer
        For r = 2 To NumMonth + 1
            DispGrid(r, 0, "Month " & r - 1)
            DispGrid(r + 1, 0, "Total Vaxed")
            DispGrid(r + 2, 0, "Average Vaxed")
            DispGrid(r + 3, 0, "% vaccines distribited p.m.")
            DispGrid(r + 4, 0, "Rating")
            DispGrid(r + 5, 0, "Fraud(Y/N)")
        Next

    End Sub

    Private Sub btnCaptData_Click(sender As Object, e As EventArgs) Handles btnCaptData.Click

        'Get region name/population
        Dim r As Integer
        For r = 1 To NumbRegion

            Regions(r).Name = InputBox("What is the name of region " & r & "?")
            DispGrid(0, r, Regions(r).Name)

            Regions(r).Population = CInt(InputBox("How many people are in region " & r & "?"))
            DispGrid(1, r, CStr(Regions(r).Population))

        Next

        'Get number of people vaxed p.m
        Dim count As Integer
        For r = 1 To NumbRegion

            For count = 1 To NumMonth

                Regions(r).VaxedPM(count) = CInt(InputBox("How many people were vaccinated in region " & r & " in month " & count))
                DispGrid(count + 1, r, CStr(Regions(r).VaxedPM(count)))

            Next

        Next
    End Sub

    Private Sub btnCalcTotAvg_Click(sender As Object, e As EventArgs) Handles btnCalcTotAvg.Click

        'Calc tot/avg
        Dim r As Integer
        For r = 1 To NumbRegion

            Regions(r).TotPRegion = 0
            Regions(r).AvgPRegion = 0

            Dim count As Integer
            For count = 1 To NumMonth

                Regions(r).TotPRegion += Regions(r).VaxedPM(count)
                Regions(r).AvgPRegion = Regions(r).TotPRegion / NumMonth

            Next

            DispGrid(NumMonth + 2, r, CStr(Regions(r).TotPRegion))
            DispGrid(NumMonth + 3, r, CStr(Regions(r).AvgPRegion))

        Next

    End Sub

    Private Sub btnCalcPerc_Click(sender As Object, e As EventArgs) Handles btnCalcPerc.Click

        'Calc % of pop vaxed
        Dim r As Integer
        For r = 1 To NumbRegion

            Regions(r).PercVaxed = Regions(r).TotPRegion / Regions(r).Population * 100
            DispGrid(NumMonth + 4, r, CStr(Regions(r).PercVaxed))

        Next

    End Sub

    'Function to do rating
    Private Function DetermainRating(ByVal p As Double) As String

        Dim rate As String
        If p <= 100 Then
            rate = "A"

            If p <= 75 Then
                rate = "B"

                If p < 56 Then
                    rate = "C"

                    If p < 25 And p >= 0 Then
                        rate = "D
"
                    End If
                End If
            End If
        End If

        Return rate

    End Function

    Private Sub btnRate_Click(sender As Object, e As EventArgs) Handles btnRate.Click

        'Rate each region(run function)
        Dim r As Integer
        For r = 1 To NumbRegion

            Regions(r).Rating = DetermainRating(Regions(r).PercVaxed)
            DispGrid(NumMonth + 5, r, CStr(Regions(r).Rating))

        Next

    End Sub

    Private Sub btnFraud_Click(sender As Object, e As EventArgs) Handles btnFraud.Click

        'Det fraud Y/N and num of regions doing fraud
        Dim r As Integer
        For r = 1 To NumbRegion

            Dim p As Double
            p = Regions(r).PercVaxed
            NumFraud = 0

            If p > 100 Then
                Regions(r).Fraud = "Y"
                DispGrid(NumMonth + 6, r, "Y")
                NumFraud += 1

            Else
                Regions(r).Fraud = "N"
                DispGrid(NumMonth + 6, r, "N")
            End If

            txtNumFraud.Text = CStr(NumFraud)

        Next

    End Sub

    Private Sub btnNeedHlp_Click(sender As Object, e As EventArgs) Handles btnNeedHlp.Click

        'Det the min % vaxed and disp name to help
        Dim Min As Double
        Dim r As Integer

        Min = Regions(1).PercVaxed
        NeedsHlp = Regions(1).Name

        For r = 2 To NumbRegion

            If Min > Regions(r).PercVaxed Then

                Min = Regions(r).PercVaxed
                NeedsHlp = Regions(r).Name

            End If

            txtNameHelp.Text = NeedsHlp

        Next

    End Sub

    Private Sub btnNumHelp_Click(sender As Object, e As EventArgs) Handles btnNumHelp.Click

        'Calc nmb of regions to help
        Dim r As Integer
        Dim P As Double
        NumHlp = 0
        For r = 1 To NumbRegion

            P = Regions(r).PercVaxed

            If P <= 50 Then
                NumHlp += 1
            End If

            txtNumHelp.Text = CStr(NumHlp)

        Next

    End Sub

End Class