﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPCMResult
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnResult = New System.Windows.Forms.Button()
        Me.txtSemTst = New System.Windows.Forms.TextBox()
        Me.txtPCM = New System.Windows.Forms.TextBox()
        Me.txtPracMark = New System.Windows.Forms.TextBox()
        Me.lblPracCompTtl = New System.Windows.Forms.Label()
        Me.lblTstM2 = New System.Windows.Forms.Label()
        Me.lblPracMs = New System.Windows.Forms.Label()
        Me.btnSetNumPrac = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.btnAddMark = New System.Windows.Forms.Button()
        Me.txtNumPrac = New System.Windows.Forms.TextBox()
        Me.lblNumPrac = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnResult
        '
        Me.btnResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnResult.Location = New System.Drawing.Point(161, 143)
        Me.btnResult.Name = "btnResult"
        Me.btnResult.Size = New System.Drawing.Size(116, 24)
        Me.btnResult.TabIndex = 19
        Me.btnResult.Text = "Result"
        Me.btnResult.UseVisualStyleBackColor = True
        '
        'txtSemTst
        '
        Me.txtSemTst.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtSemTst.Location = New System.Drawing.Point(161, 96)
        Me.txtSemTst.Name = "txtSemTst"
        Me.txtSemTst.Size = New System.Drawing.Size(79, 20)
        Me.txtSemTst.TabIndex = 18
        '
        'txtPCM
        '
        Me.txtPCM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtPCM.Location = New System.Drawing.Point(161, 193)
        Me.txtPCM.Name = "txtPCM"
        Me.txtPCM.ReadOnly = True
        Me.txtPCM.Size = New System.Drawing.Size(186, 20)
        Me.txtPCM.TabIndex = 17
        '
        'txtPracMark
        '
        Me.txtPracMark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtPracMark.Location = New System.Drawing.Point(161, 60)
        Me.txtPracMark.Name = "txtPracMark"
        Me.txtPracMark.Size = New System.Drawing.Size(79, 20)
        Me.txtPracMark.TabIndex = 14
        '
        'lblPracCompTtl
        '
        Me.lblPracCompTtl.AutoSize = True
        Me.lblPracCompTtl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblPracCompTtl.Location = New System.Drawing.Point(10, 196)
        Me.lblPracCompTtl.Name = "lblPracCompTtl"
        Me.lblPracCompTtl.Size = New System.Drawing.Size(132, 13)
        Me.lblPracCompTtl.TabIndex = 12
        Me.lblPracCompTtl.Text = "Practical Component Total"
        '
        'lblTstM2
        '
        Me.lblTstM2.AutoSize = True
        Me.lblTstM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblTstM2.Location = New System.Drawing.Point(58, 103)
        Me.lblTstM2.Name = "lblTstM2"
        Me.lblTstM2.Size = New System.Drawing.Size(84, 13)
        Me.lblTstM2.TabIndex = 11
        Me.lblTstM2.Text = "Semester Test 2"
        '
        'lblPracMs
        '
        Me.lblPracMs.AutoSize = True
        Me.lblPracMs.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblPracMs.Location = New System.Drawing.Point(62, 67)
        Me.lblPracMs.Name = "lblPracMs"
        Me.lblPracMs.Size = New System.Drawing.Size(80, 13)
        Me.lblPracMs.TabIndex = 10
        Me.lblPracMs.Text = "Pracrical Marks"
        '
        'btnSetNumPrac
        '
        Me.btnSetNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnSetNumPrac.Location = New System.Drawing.Point(277, 22)
        Me.btnSetNumPrac.Name = "btnSetNumPrac"
        Me.btnSetNumPrac.Size = New System.Drawing.Size(141, 26)
        Me.btnSetNumPrac.TabIndex = 20
        Me.btnSetNumPrac.Text = "Set Up Number"
        Me.btnSetNumPrac.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtResult.Location = New System.Drawing.Point(161, 245)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.Size = New System.Drawing.Size(186, 20)
        Me.txtResult.TabIndex = 21
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblResult.Location = New System.Drawing.Point(105, 248)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(37, 13)
        Me.lblResult.TabIndex = 22
        Me.lblResult.Text = "Result"
        '
        'btnAddMark
        '
        Me.btnAddMark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnAddMark.Location = New System.Drawing.Point(277, 54)
        Me.btnAddMark.Name = "btnAddMark"
        Me.btnAddMark.Size = New System.Drawing.Size(141, 26)
        Me.btnAddMark.TabIndex = 23
        Me.btnAddMark.Text = "Add Practical Mark"
        Me.btnAddMark.UseVisualStyleBackColor = True
        '
        'txtNumPrac
        '
        Me.txtNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtNumPrac.Location = New System.Drawing.Point(161, 26)
        Me.txtNumPrac.Name = "txtNumPrac"
        Me.txtNumPrac.Size = New System.Drawing.Size(79, 20)
        Me.txtNumPrac.TabIndex = 24
        '
        'lblNumPrac
        '
        Me.lblNumPrac.AutoSize = True
        Me.lblNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblNumPrac.Location = New System.Drawing.Point(37, 33)
        Me.lblNumPrac.Name = "lblNumPrac"
        Me.lblNumPrac.Size = New System.Drawing.Size(105, 13)
        Me.lblNumPrac.TabIndex = 25
        Me.lblNumPrac.Text = "Number of Practicals"
        '
        'frmPCMResult
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 296)
        Me.Controls.Add(Me.lblNumPrac)
        Me.Controls.Add(Me.txtNumPrac)
        Me.Controls.Add(Me.btnAddMark)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.btnSetNumPrac)
        Me.Controls.Add(Me.btnResult)
        Me.Controls.Add(Me.txtSemTst)
        Me.Controls.Add(Me.txtPCM)
        Me.Controls.Add(Me.txtPracMark)
        Me.Controls.Add(Me.lblPracCompTtl)
        Me.Controls.Add(Me.lblTstM2)
        Me.Controls.Add(Me.lblPracMs)
        Me.Name = "frmPCMResult"
        Me.Text = "PCM Result"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnResult As Button
    Friend WithEvents txtSemTst As TextBox
    Friend WithEvents txtPCM As TextBox
    Friend WithEvents txtPracMark As TextBox
    Friend WithEvents lblPracCompTtl As Label
    Friend WithEvents lblTstM2 As Label
    Friend WithEvents lblPracMs As Label
    Friend WithEvents btnSetNumPrac As Button
    Friend WithEvents txtResult As TextBox
    Friend WithEvents lblResult As Label
    Friend WithEvents btnAddMark As Button
    Friend WithEvents txtNumPrac As TextBox
    Friend WithEvents lblNumPrac As Label
End Class
