﻿' ****************************************************************************
' Surname, Initials: Mayet,AA
' Student Number: 222001975
' Practical: P2022A-03
' Class name: frmPCMResults
' ****************************************************************************

Option Strict On
Option Explicit On

Public Class frmPCMResult

    'Declare all variables

    Private NumPracCalc As Integer
    Private NumPrac As Integer
    Private PracMark As Double
    Private PracTotal As Double
    Private PracCalc As Double
    Private SemTst As Double
    Private TestCalc As Double
    Private PCM As Double

    Private Sub btnSetNumPrac_Click(sender As Object, e As EventArgs) Handles btnSetNumPrac.Click
        'Get number of Practicals from the user and store them in 2 variables, one for calculations (PCM) and another for reference
        NumPracCalc = CInt(txtNumPrac.Text)
        NumPrac = CInt(txtNumPrac.Text)

    End Sub

    Private Sub btnAddMark_Click(sender As Object, e As EventArgs) Handles btnAddMark.Click
        'Get all marks from user
        If NumPrac <> 0 Then
            PracMark = CDbl(txtPracMark.Text)
            'Add marks from user
            PracTotal = PracTotal + PracMark
            NumPrac = NumPrac - 1
        Else
            'Once number of practicals are added ask for the semster test mark
            txtPCM.Text = "Insert Semester Test Mark"
            txtResult.Text = "Insert Semester Test Mark"

        End If

    End Sub

    Private Sub btnResult_Click(sender As Object, e As EventArgs) Handles btnResult.Click
        'Calculate the PCM once all practical marks are added and entered
        If NumPrac = 0 Then
            PracCalc = (PracTotal / NumPracCalc) * (10 / 75)
            SemTst = CDbl(txtSemTst.Text)
            TestCalc = SemTst * (65 / 75)
            PCM = PracCalc + TestCalc
            'Show the answer to the user
            txtPCM.Text = CStr(PCM)
            'Let user know their results:
            If PCM >= 70 Then
                txtResult.Text = "Exemption"
            End If

            If PCM >= 40 And PCM < 70 Then
                txtResult.Text = "Exam Qualification"
            End If

            If PCM < 40 Then
                txtResult.Text = "No Access to Exam"
            End If

        Else
            'If not all prac marks were added then ask for the rest
            txtPCM.Text = "ADD " & CStr(NumPrac) & " MORE PRACTICAL MARKS"
            txtResult.Text = “ADD “ & CStr(NumPrac) & " MORE PRACTICAL MARKS"
        End If

    End Sub

End Class
