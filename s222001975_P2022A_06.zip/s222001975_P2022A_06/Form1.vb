﻿' ****************************************************************************
' Surname, Initials: Mayet,AA
' Student Number: 222001975
' Practical: P2022A-06
' Class name: frmVaxTrack
' ****************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmVaxTrack

    'Declare all variables
    Private NumDayVax As Integer
    Private CountDayVax As Integer
    Private NumVaxed() As Integer
    Private TtlVaxedCalc As Integer
    Private TtlVaxed As Integer
    Private AvgCalc As Double
    Private Avg As Double
    Private AddDay As Integer
    Private AddNumVaxed As Integer
    Private NumVaxCalc As Integer

    'Create subroutine for configuring the uj grid
    Private Sub GridConfig(ByVal Rs As Integer, ByVal Cs As Integer)

        grdVaxPpl.Rows = Rs
        grdVaxPpl.Cols = Cs

    End Sub

    'Create subroutine for displaying text on uj grid
    Private Sub GridDisp(ByVal r As Integer, ByVal c As Integer, ByVal t As String)

        grdVaxPpl.Row = r
        grdVaxPpl.Col = c
        grdVaxPpl.Text = t

    End Sub

    'Whay the user sees when they start the program
    Private Sub frmVaxTrack_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GridConfig(3, 2)
        GridDisp(0, 0, "Day")
        GridDisp(0, 1, "No. of People")

    End Sub

    'Create a function to calculate the Total people who have vaxed
    Private Function CalcTtl(ByRef NumVaxCalc As Integer) As Integer

        TtlVaxedCalc = TtlVaxedCalc + NumVaxCalc
        Return TtlVaxedCalc

    End Function

    'Create a function to calcuale the average people who have vaxed
    Private Function CalcAvg(ByVal TtlVaxed As Integer, ByVal NumDayVax As Integer) As Double

        AvgCalc = TtlVaxed / NumDayVax
        Return AvgCalc

    End Function

    Private Sub btnInitialize_Click(sender As Object, e As EventArgs) Handles btnInitialize.Click

        'Get the number of days people are vaccinating
        NumDayVax = CInt(InputBox("How many days are you vaccinating?"))

        'Initialize all variables
        CountDayVax = 0
        TtlVaxedCalc = 0
        TtlVaxed = 0
        AvgCalc = 0
        Avg = 0
        AddDay = 0
        AddNumVaxed = 0
        NumVaxCalc = 0

        'Make rows and cols on grid
        GridConfig(1, 2)

        'Resize the dynamic array
        ReDim NumVaxed(NumDayVax)

    End Sub

    Private Sub btnVaxed_Click(sender As Object, e As EventArgs) Handles btnVaxed.Click

        'Set up the uj grid
        GridConfig(NumDayVax + 3, 2)
        GridDisp(NumDayVax + 1, 0, "Total Vaxed")
        GridDisp(NumDayVax + 2, 0, "Avg Vaxed")

        For CountDayVax = 1 To NumDayVax Step +1

            'Get the number of people who have vaxed each day and store the values
            NumVaxed(CountDayVax) = CInt(InputBox("How mant people have been vaxed on day " & CountDayVax & "?"))

            'Display values on the grid
            GridDisp(CountDayVax, 0, "Day " & CountDayVax)
            GridDisp(CountDayVax, 1, CStr(NumVaxed(CountDayVax)))

            'This variable is used for the calculations in the function
            NumVaxCalc = NumVaxed(CountDayVax)

            'Calc and disp the total people who vaxed
            TtlVaxed = CalcTtl(NumVaxCalc)
            GridDisp(NumDayVax + 1, 1, CStr(TtlVaxed))

            'Calc and disp avg people who vaxed
            Avg = CalcAvg(TtlVaxed, NumDayVax)
            GridDisp(NumDayVax + 2, 1, CStr(Avg))

        Next CountDayVax

    End Sub

    Private Sub btnAddPpl_Click(sender As Object, e As EventArgs) Handles btnAddPpl.Click

        'Find out what day there were additional vaccinations
        AddDay = CInt(InputBox("What day would you like to add aditional people to?"))
        'This is used to help storing the new number and for calculations
        CountDayVax = AddDay

        'Get the additional number of people who have vaxed
        AddNumVaxed = CInt(InputBox("How many more people would you like to add to day " & AddDay & "?"))
        'Change the stored value in the array
        NumVaxed(CountDayVax) = NumVaxed(CountDayVax) + AddNumVaxed

        'Disp the new number of people
        GridDisp(CountDayVax, 1, CStr(NumVaxed(CountDayVax)))

        'Calc and disp new total number of peope who have vaxed
        TtlVaxed = CalcTtl(AddNumVaxed)
        GridDisp(NumDayVax + 1, 1, CStr(TtlVaxed))

        'Calc and disp new average number of people who have vaxed
        Avg = CalcAvg(TtlVaxed, NumDayVax)
        GridDisp(NumDayVax + 2, 1, CStr(Avg))

    End Sub

End Class