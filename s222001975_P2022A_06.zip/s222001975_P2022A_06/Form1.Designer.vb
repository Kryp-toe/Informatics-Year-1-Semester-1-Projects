﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVaxTrack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdVaxPpl = New UJGrid.UJGrid()
        Me.btnInitialize = New System.Windows.Forms.Button()
        Me.btnAddPpl = New System.Windows.Forms.Button()
        Me.btnVaxed = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdVaxPpl
        '
        Me.grdVaxPpl.FixedCols = 2
        Me.grdVaxPpl.FixedRows = 1
        Me.grdVaxPpl.Location = New System.Drawing.Point(49, 44)
        Me.grdVaxPpl.Name = "grdVaxPpl"
        Me.grdVaxPpl.Rows = 1
        Me.grdVaxPpl.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdVaxPpl.Size = New System.Drawing.Size(218, 394)
        Me.grdVaxPpl.TabIndex = 0
        '
        'btnInitialize
        '
        Me.btnInitialize.Location = New System.Drawing.Point(33, 14)
        Me.btnInitialize.Name = "btnInitialize"
        Me.btnInitialize.Size = New System.Drawing.Size(75, 24)
        Me.btnInitialize.TabIndex = 1
        Me.btnInitialize.Text = "Initialize"
        Me.btnInitialize.UseVisualStyleBackColor = True
        '
        'btnAddPpl
        '
        Me.btnAddPpl.Location = New System.Drawing.Point(195, 15)
        Me.btnAddPpl.Name = "btnAddPpl"
        Me.btnAddPpl.Size = New System.Drawing.Size(75, 24)
        Me.btnAddPpl.TabIndex = 2
        Me.btnAddPpl.Text = "Add People"
        Me.btnAddPpl.UseVisualStyleBackColor = True
        '
        'btnVaxed
        '
        Me.btnVaxed.Location = New System.Drawing.Point(114, 15)
        Me.btnVaxed.Name = "btnVaxed"
        Me.btnVaxed.Size = New System.Drawing.Size(75, 24)
        Me.btnVaxed.TabIndex = 3
        Me.btnVaxed.Text = "Vaccinated"
        Me.btnVaxed.UseVisualStyleBackColor = True
        '
        'frmVaxTrack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 450)
        Me.Controls.Add(Me.btnVaxed)
        Me.Controls.Add(Me.btnAddPpl)
        Me.Controls.Add(Me.btnInitialize)
        Me.Controls.Add(Me.grdVaxPpl)
        Me.Name = "frmVaxTrack"
        Me.Text = "Vaccination Tracker"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdVaxPpl As UJGrid.UJGrid
    Friend WithEvents btnInitialize As Button
    Friend WithEvents btnAddPpl As Button
    Friend WithEvents btnVaxed As Button
End Class
