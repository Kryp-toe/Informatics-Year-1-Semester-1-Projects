﻿'***********************************************************************************
'Surename, Initials: Mayet,AA
'Student number: 222001975
'Practical: P2022A_12
'Class: frmGoaTyPirate
'************************************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Public Class frmGoaTyPirate

    'Declare variables and record structures
    Private nSeasons As Integer
    Private nEpisodes As Integer
    Private nCountry As Integer
    Private Col As Integer
    Private MostPiratInd() As Integer
    Private Season() As SeasonRec
    Private Structure SeasonRec
        Public Number As String
        Public ExecProd As Integer
        Public MostPirate As String
        Public Rate As String
        Public Episodes() As EpisodeRec
    End Structure
    Private Structure EpisodeRec
        Public Name As String
        Public Minutes As Integer
        Public Pirate As Integer
        Public TotPirate As Integer
    End Structure

    'Grid set up
    Private Sub SetUpGrid(ByVal C As Integer, ByVal R As Integer)
        grdGoaTyPirate.Cols = C
        grdGoaTyPirate.Rows = R
    End Sub

    'Grid display
    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdGoaTyPirate.Col = c
        grdGoaTyPirate.Row = r
        grdGoaTyPirate.Text = t
    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get no. seasons/countries/episodes
        nSeasons = CInt(InputBox("How many seasons are there?"))
        nEpisodes = CInt(InputBox("How many episodes are there in each season?"))
        nCountry = CInt(InputBox("How many countries are you monitoring?"))

        'Size all arrays
        ReDim MostPiratInd(nSeasons)
        ReDim Season(nSeasons)
        Dim s As Integer
        For s = 1 To nSeasons

            ReDim Season(s).Episodes(nEpisodes)
            Season(s).Number = CStr(s)
            DispGrid(0, s, CStr(s))

        Next

        'Set up grid
        SetUpGrid(nEpisodes * 3 + 4, nSeasons + 1)

        'Set up display
        DispGrid(0, 0, "Season")
        DispGrid(1, 0, "No. Producers")
        DispGrid(nEpisodes * 3 + 2, 0, "Most Pirated Episode")
        DispGrid(nEpisodes * 3 + 3, 0, "Rating")
        Col = nEpisodes * 3
        Dim c As Integer
        For c = 1 To Col Step +3
            DispGrid(c + 1, 0, "Episode Name")
            DispGrid(c + 2, 0, "Minutes")
            DispGrid(c + 3, 0, "Times Pirated")
        Next

    End Sub

    Private Sub btnInput_Click(sender As Object, e As EventArgs) Handles btnInput.Click

        Dim s As Integer
        For s = 1 To nSeasons

            'Get number of exec producers and disp
            Season(s).ExecProd = CInt(InputBox("How many executive producers are there in season " & s))
            DispGrid(1, s, CStr(Season(s).ExecProd))

            Dim ep As Integer
            For ep = 1 To nEpisodes

                'Get name and time of every episode and disp
                Season(s).Episodes(ep).Name = InputBox("What is the name of episode " & ep & " in season " & s)
                DispGrid((3 * ep) - 1, s, Season(s).Episodes(ep).Name)
                Season(s).Episodes(ep).Minutes = CInt(InputBox("How long is " & Season(s).Episodes(ep).Name))
                DispGrid(3 * ep, s, CStr(Season(s).Episodes(ep).Minutes))

            Next

        Next

    End Sub

    Private Sub btnNoPirate_Click(sender As Object, e As EventArgs) Handles btnNoPirate.Click

        Dim s As Integer
        For s = 1 To nSeasons

            Dim ep As Integer
            For ep = 1 To nEpisodes

                'Initialize total
                Season(s).Episodes(ep).TotPirate = 0

                Dim c As Integer
                For c = 1 To nCountry

                    'Get no. times episodes were pirated and add to total
                    Season(s).Episodes(ep).Pirate = CInt(InputBox("How many times was " & Season(s).Episodes(ep).Name & " pirated in country " & c))
                    Season(s).Episodes(ep).TotPirate += Season(s).Episodes(ep).Pirate

                Next

                'Disp total
                DispGrid((3 * ep) + 1, s, CStr(Season(s).Episodes(ep).TotPirate))

            Next

        Next

    End Sub

    Private Sub btnMostPirated_Click(sender As Object, e As EventArgs) Handles btnMostPirated.Click

        Dim s As Integer
        For s = 1 To nSeasons

            'Initialize max, index and mostpirated episode per season
            Dim Max As Integer
            Season(s).MostPirate = Season(s).Episodes(1).Name
            MostPiratInd(s) = 1
            Max = Season(s).Episodes(MostPiratInd(s)).TotPirate

            Dim ep As Integer
            For ep = 2 To nEpisodes

                'Det new max and change values accordingly
                If Max < Season(s).Episodes(ep).TotPirate Then
                    MostPiratInd(s) = ep
                    Max = Season(s).Episodes(MostPiratInd(s)).TotPirate
                End If

            Next

            'Det most pirated episode and disp
            Season(s).MostPirate = Season(s).Episodes(MostPiratInd(s)).Name
            DispGrid((3 * nEpisodes) + 2, s, Season(s).MostPirate)

        Next

    End Sub

    'Sub to convert to hours
    Private Sub ConvertToHours(ByVal Time As Integer, ByRef Hrs As Integer, ByRef Min As Integer)

        Hrs = CInt(Time / 60)
        '  Min = Time - (Hrs * 60)
        Min = Time Mod 60
    End Sub

    Private Sub btnRate_Click(sender As Object, e As EventArgs) Handles btnRate.Click

        Dim s As Integer
        For s = 1 To nSeasons

            Dim THrs As Integer
            Dim TMin As Integer
            'Initialize hoyrs/minutes
            THrs = 0
            TMin = 0

            'Run sub
            ConvertToHours(Season(s).Episodes(MostPiratInd(s)).Minutes, THrs, TMin)

            Dim response As String
            Select Case THrs
                'hours > 0
                Case > 0
                    '30 to 59
                    If TMin <= 59 Then
                        response = "6"

                        '1 to 30
                        If TMin <= 30 Then
                            response = "4"

                            '0
                            If TMin = 0 Then
                                response = "2"
                            End If
                        End If
                    End If

                Case = 0
                    If TMin <= 59 Then
                        response = "5"

                        If TMin <= 30 Then
                            response = "3"

                            If TMin = 0 Then
                                response = "1"
                            End If
                        End If
                    End If

            End Select

            'Disp response
            Season(s).Rate = response
            DispGrid((3 * nEpisodes) + 3, s, response)

        Next

    End Sub

    Private Sub btnIncrease_Click(sender As Object, e As EventArgs) Handles btnIncrease.Click

        Dim s As Integer
        For s = 1 To nSeasons - 1

            Dim response As String
            Dim current As Integer
            current = Season(s).ExecProd

            If current < Season(s + 1).ExecProd Then

                If current > Season(s - 1).ExecProd Then
                    response = "Increasing"
                Else
                    response = "NOT Increasing"
                End If

            Else
                response = "NOT Increasing"
            End If

            txtIncrase.Text = response

        Next

    End Sub

End Class