﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGoaTyPirate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnInput = New System.Windows.Forms.Button()
        Me.btnNoPirate = New System.Windows.Forms.Button()
        Me.btnMostPirated = New System.Windows.Forms.Button()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.btnIncrease = New System.Windows.Forms.Button()
        Me.lblIncrease = New System.Windows.Forms.Label()
        Me.grdGoaTyPirate = New UJGrid.UJGrid()
        Me.txtIncrase = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(148, 26)
        Me.btnInitial.TabIndex = 0
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnInput
        '
        Me.btnInput.Location = New System.Drawing.Point(166, 12)
        Me.btnInput.Name = "btnInput"
        Me.btnInput.Size = New System.Drawing.Size(148, 26)
        Me.btnInput.TabIndex = 1
        Me.btnInput.Text = "Input"
        Me.btnInput.UseVisualStyleBackColor = True
        '
        'btnNoPirate
        '
        Me.btnNoPirate.Location = New System.Drawing.Point(320, 12)
        Me.btnNoPirate.Name = "btnNoPirate"
        Me.btnNoPirate.Size = New System.Drawing.Size(148, 26)
        Me.btnNoPirate.TabIndex = 2
        Me.btnNoPirate.Text = "Number of times Pirated"
        Me.btnNoPirate.UseVisualStyleBackColor = True
        '
        'btnMostPirated
        '
        Me.btnMostPirated.Location = New System.Drawing.Point(474, 12)
        Me.btnMostPirated.Name = "btnMostPirated"
        Me.btnMostPirated.Size = New System.Drawing.Size(148, 26)
        Me.btnMostPirated.TabIndex = 3
        Me.btnMostPirated.Text = "Most Pirated Episode"
        Me.btnMostPirated.UseVisualStyleBackColor = True
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(628, 12)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(148, 26)
        Me.btnRate.TabIndex = 4
        Me.btnRate.Text = "Season Rating"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'btnIncrease
        '
        Me.btnIncrease.Location = New System.Drawing.Point(181, 219)
        Me.btnIncrease.Name = "btnIncrease"
        Me.btnIncrease.Size = New System.Drawing.Size(75, 23)
        Me.btnIncrease.TabIndex = 6
        Me.btnIncrease.Text = "Result"
        Me.btnIncrease.UseVisualStyleBackColor = True
        '
        'lblIncrease
        '
        Me.lblIncrease.AutoSize = True
        Me.lblIncrease.Location = New System.Drawing.Point(14, 230)
        Me.lblIncrease.Name = "lblIncrease"
        Me.lblIncrease.Size = New System.Drawing.Size(55, 13)
        Me.lblIncrease.TabIndex = 7
        Me.lblIncrease.Text = "Producers"
        '
        'grdGoaTyPirate
        '
        Me.grdGoaTyPirate.Cols = 10
        Me.grdGoaTyPirate.FixedCols = 1
        Me.grdGoaTyPirate.FixedRows = 1
        Me.grdGoaTyPirate.Location = New System.Drawing.Point(12, 65)
        Me.grdGoaTyPirate.Name = "grdGoaTyPirate"
        Me.grdGoaTyPirate.Rows = 6
        Me.grdGoaTyPirate.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdGoaTyPirate.Size = New System.Drawing.Size(764, 150)
        Me.grdGoaTyPirate.TabIndex = 8
        '
        'txtIncrase
        '
        Me.txtIncrase.Location = New System.Drawing.Point(75, 221)
        Me.txtIncrase.Name = "txtIncrase"
        Me.txtIncrase.Size = New System.Drawing.Size(100, 20)
        Me.txtIncrase.TabIndex = 9
        '
        'frmGoaTyPirate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(791, 255)
        Me.Controls.Add(Me.txtIncrase)
        Me.Controls.Add(Me.grdGoaTyPirate)
        Me.Controls.Add(Me.lblIncrease)
        Me.Controls.Add(Me.btnIncrease)
        Me.Controls.Add(Me.btnRate)
        Me.Controls.Add(Me.btnMostPirated)
        Me.Controls.Add(Me.btnNoPirate)
        Me.Controls.Add(Me.btnInput)
        Me.Controls.Add(Me.btnInitial)
        Me.Name = "frmGoaTyPirate"
        Me.Text = "GoaTy Pirated Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnInitial As Button
    Friend WithEvents btnInput As Button
    Friend WithEvents btnNoPirate As Button
    Friend WithEvents btnMostPirated As Button
    Friend WithEvents btnRate As Button
    Friend WithEvents btnIncrease As Button
    Friend WithEvents lblIncrease As Label
    Friend WithEvents grdGoaTyPirate As UJGrid.UJGrid
    Friend WithEvents txtIncrase As TextBox
End Class
