﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBstsTour
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdBtsTour = New UJGrid.UJGrid()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnInpData = New System.Windows.Forms.Button()
        Me.btnPhotosTaken = New System.Windows.Forms.Button()
        Me.btnCalcRatio = New System.Windows.Forms.Button()
        Me.btnHighRatio = New System.Windows.Forms.Button()
        Me.btnCalcResult = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'grdBtsTour
        '
        Me.grdBtsTour.Cols = 15
        Me.grdBtsTour.FixedCols = 1
        Me.grdBtsTour.FixedRows = 1
        Me.grdBtsTour.Location = New System.Drawing.Point(12, 44)
        Me.grdBtsTour.Name = "grdBtsTour"
        Me.grdBtsTour.Rows = 6
        Me.grdBtsTour.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdBtsTour.Size = New System.Drawing.Size(862, 150)
        Me.grdBtsTour.TabIndex = 0
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(722, 12)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(136, 26)
        Me.btnRate.TabIndex = 2
        Me.btnRate.Text = "Rating"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(136, 26)
        Me.btnInitial.TabIndex = 3
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnInpData
        '
        Me.btnInpData.Location = New System.Drawing.Point(154, 12)
        Me.btnInpData.Name = "btnInpData"
        Me.btnInpData.Size = New System.Drawing.Size(136, 26)
        Me.btnInpData.TabIndex = 4
        Me.btnInpData.Text = "Input Data"
        Me.btnInpData.UseVisualStyleBackColor = True
        '
        'btnPhotosTaken
        '
        Me.btnPhotosTaken.Location = New System.Drawing.Point(296, 12)
        Me.btnPhotosTaken.Name = "btnPhotosTaken"
        Me.btnPhotosTaken.Size = New System.Drawing.Size(136, 26)
        Me.btnPhotosTaken.TabIndex = 5
        Me.btnPhotosTaken.Text = "Number of Photos Taken"
        Me.btnPhotosTaken.UseVisualStyleBackColor = True
        '
        'btnCalcRatio
        '
        Me.btnCalcRatio.Location = New System.Drawing.Point(438, 12)
        Me.btnCalcRatio.Name = "btnCalcRatio"
        Me.btnCalcRatio.Size = New System.Drawing.Size(136, 26)
        Me.btnCalcRatio.TabIndex = 6
        Me.btnCalcRatio.Text = "Calculate Ratio"
        Me.btnCalcRatio.UseVisualStyleBackColor = True
        '
        'btnHighRatio
        '
        Me.btnHighRatio.Location = New System.Drawing.Point(580, 12)
        Me.btnHighRatio.Name = "btnHighRatio"
        Me.btnHighRatio.Size = New System.Drawing.Size(136, 26)
        Me.btnHighRatio.TabIndex = 7
        Me.btnHighRatio.Text = "Calculate Highest Ratio"
        Me.btnHighRatio.UseVisualStyleBackColor = True
        '
        'btnCalcResult
        '
        Me.btnCalcResult.Location = New System.Drawing.Point(340, 200)
        Me.btnCalcResult.Name = "btnCalcResult"
        Me.btnCalcResult.Size = New System.Drawing.Size(136, 30)
        Me.btnCalcResult.TabIndex = 8
        Me.btnCalcResult.Text = "Increasing or Remain"
        Me.btnCalcResult.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(192, 200)
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.Size = New System.Drawing.Size(142, 30)
        Me.txtResult.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 209)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Destination with Highest Destination"
        '
        'frmBstsTour
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(886, 238)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.btnCalcResult)
        Me.Controls.Add(Me.btnHighRatio)
        Me.Controls.Add(Me.btnCalcRatio)
        Me.Controls.Add(Me.btnPhotosTaken)
        Me.Controls.Add(Me.btnInpData)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.btnRate)
        Me.Controls.Add(Me.grdBtsTour)
        Me.Name = "frmBstsTour"
        Me.Text = "Botswana Tourism Tracker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grdBtsTour As UJGrid.UJGrid
    Friend WithEvents btnRate As Button
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnInpData As Button
    Friend WithEvents btnPhotosTaken As Button
    Friend WithEvents btnCalcRatio As Button
    Friend WithEvents btnHighRatio As Button
    Friend WithEvents btnCalcResult As Button
    Friend WithEvents txtResult As TextBox
    Friend WithEvents Label1 As Label
End Class
