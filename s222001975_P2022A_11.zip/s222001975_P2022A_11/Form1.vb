﻿'****************************************************************************************
'Surename, Intials: Mayet, AA
'Student Number: 222001975
'Practical: P2022A_11
'Class: frmBstsTour
'********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmBstsTour

    'Declare variables and structures
    Private nDest As Integer
    Private nAct As Integer
    Private nSMSites As Integer
    Private Col As Integer
    Private MaxAct() As Integer
    Private Dest() As DestRec
    Private Structure DestRec
        Public Name As String
        Public Act() As ActRec
        Public HighRatio As String
        Public Rate As String
    End Structure
    Private Structure ActRec
        Public Name As String
        Public nVisit As Integer
        Public Photo As Integer
        Public TotPhoto As Integer
        Public Ratio As Double
    End Structure

    'Sub for setting up grid
    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdBtsTour.Rows = R
        grdBtsTour.Cols = C
    End Sub

    'Sub for grid disp
    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdBtsTour.Row = r
        grdBtsTour.Col = c
        grdBtsTour.Text = t
    End Sub

    'Label grid on start
    Private Sub frmBstsTour_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetGrid(15, 7)
        DispGrid(0, 0, "Destination Name:")
        DispGrid(1, 0, "Activities:")
        DispGrid(2, 0, "Highest Ratio")
        DispGrid(3, 0, "Rating")
    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'No. of destinations,activities,socialmedia sites
        nDest = CInt(InputBox("Hw many Destinations are you recording"))
        nAct = CInt(InputBox("How many Activities are you recording"))
        nSMSites = CInt(InputBox("How many Social Media platforms are you capturing"))

        'Resize arrays/structures
        ReDim Dest(nDest)
        ReDim MaxAct(nDest)

        Dim d As Integer
        For d = 1 To nDest
            ReDim Dest(d).Act(nAct)
        Next

        'Set up grid and label
        Col = (nAct * 4)
        SetGrid(Col + 3, nDest + 1)


        DispGrid(0, 0, "Destination Name:")

        DispGrid(Col + 1, 0, "Highest Ratio")
        DispGrid(Col + 2, 0, "Rating")

        Dim cl As Integer
        For cl = 1 To Col Step +4
            DispGrid(cl, 0, "Name")
            DispGrid(cl + 1, 0, "  No. Visitors")
            DispGrid(cl + 2, 0, "  Total Photos")
            DispGrid(cl + 3, 0, "  Ratio")
        Next

    End Sub

    Private Sub btnInpData_Click(sender As Object, e As EventArgs) Handles btnInpData.Click

        'In each destination:
        Dim d As Integer
        For d = 1 To nDest

            'Get the name of destination and disp
            Dest(d).Name = InputBox("What is the name of destination " & d)
            DispGrid(0, d, Dest(d).Name)

            'In each act:
            Dim a As Integer
            For a = 1 To nAct

                'Get name, no.visitores and disp
                Dest(d).Act(a).Name = InputBox("What is the name of activity " & a & " in " & Dest(d).Name)
                Dest(d).Act(a).nVisit = CInt(InputBox("How many people visited " & Dest(d).Act(a).Name))
                DispGrid(4 * a - 3, d, Dest(d).Act(a).Name)
                DispGrid(4 * a - 2, d, CStr(Dest(d).Act(a).nVisit))

            Next

        Next

    End Sub

    Private Sub btnPhotosTaken_Click(sender As Object, e As EventArgs) Handles btnPhotosTaken.Click

        'For each dest:
        Dim d As Integer
        For d = 1 To nDest

            'For each act:
            Dim a As Integer
            For a = 1 To nAct

                'Initialize photots
                Dest(d).Act(a).TotPhoto = 0
                Dest(d).Act(a).Photo = 0

                'In each site:
                Dim s As Integer
                For s = 1 To nSMSites

                    'Get no. photos, add to total, disp total
                    Dest(d).Act(a).Photo = CInt(InputBox("How many pictures were posted on Social Media site " & s & " for " & Dest(d).Act(a).Name & " in " & Dest(d).Name))
                    Dest(d).Act(a).TotPhoto += Dest(d).Act(a).Photo
                    DispGrid(4 * a - 1, d, CStr(Dest(d).Act(a).TotPhoto))

                Next

            Next

        Next

    End Sub

    'Finction to calc ratio
    Private Sub CalcRatio(ByVal a As Integer, ByVal b As Integer, ByRef c As Double)
        c = a / b
    End Sub

    Private Sub btnCalcRatio_Click(sender As Object, e As EventArgs) Handles btnCalcRatio.Click

        'In each dest
        Dim d As Integer
        For d = 1 To nDest

            'For every act
            Dim a As Integer
            For a = 1 To nAct

                'Calc ratio of photos-visitors, display
                CalcRatio(Dest(d).Act(a).TotPhoto, Dest(d).Act(a).nVisit, Dest(d).Act(a).Ratio)
                DispGrid(4 * a, d, Format(Dest(d).Act(a).Ratio, "0.0"))

            Next

        Next

    End Sub

    Private Sub btnHighRatio_Click(sender As Object, e As EventArgs) Handles btnHighRatio.Click

        'In every dest
        Dim d As Integer
        For d = 1 To nDest

            'Initialize max vaues
            Dim Max As Double
            Max = Dest(d).Act(1).Ratio
            MaxAct(d) = 1

            'For every act(from2) 
            Dim a As Integer
            For a = 2 To nAct

                'Find new max(if there is)
                If Max < Dest(d).Act(a).Ratio Then
                    Max = Dest(d).Act(a).Ratio
                    'Make act new max
                    MaxAct(d) = a
                End If

            Next

            'Get name of new max and disp
            Dest(d).HighRatio = Dest(d).Act(MaxAct(d)).Name
            DispGrid(Col + 1, d, Dest(d).HighRatio)

        Next

    End Sub

    Private Sub btnRate_Click(sender As Object, e As EventArgs) Handles btnRate.Click

        'In every dest
        Dim d As Integer
        For d = 1 To nDest

            '/2 then take remainder
            Dim Remain As Double
            Remain = Dest(d).Act(MaxAct(d)).Ratio Mod 2

            Select Case Remain

                'If there is a even/no remainder then even Else odd
                Case 0, 0.2, 0.4, 0.6, 0.8
                    DispGrid(Col + 2, d, "Even")

                Case Else
                    DispGrid(Col + 2, d, "Odd")

            End Select

        Next

    End Sub

    Private Sub btnCalcResult_Click(sender As Object, e As EventArgs) Handles btnCalcResult.Click

        'For every dest
        Dim d As Integer
        Dim prev As Double
        For d = 2 To nDest

            'Make first dest/act 1 the initial
            prev = Dest(1).Act(1).Ratio

            'Det if numbers are increasing
            If prev > Dest(d).Act(MaxAct(d)).Ratio Then
                txtResult.Text = "Increasing"
            ElseIf prev < Dest(d).Act(MaxAct(d)).Ratio Then
                txtResult.Text = "Decreasing"
            Else
                txtResult.Text = "Remains the same"
            End If

        Next

    End Sub

End Class