﻿' *****************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022A-10
' Class name: frmDeptFileSize
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Public Class frmDeptFileSize
    'Declare variables and structures
    Private nDepts As Integer
    Private nMod As Integer
    Private nWeek As Integer
    Private Departments() As DepartmentsRec
    Private Structure DepartmentsRec
        Public Name As String
        Public nStudents As Integer
        Public Modules() As ModulesRec
        Public DeptTotSize As Double
        Public ModAvg As Double
        Public DeptRate As String
    End Structure
    Private Structure ModulesRec
        Public Code As String
        Public WeekSize As Double
        Public ModTotSize As Double
    End Structure

    'Set up a sub for uj grid and grid display
    Private Sub SetGrid(ByRef R As Integer, ByRef C As Integer)
        grdDeptFileSize.Rows = R
        grdDeptFileSize.Cols = C
    End Sub

    Private Sub GridDisp(ByRef r As Integer, ByRef c As Integer, ByRef t As String)
        grdDeptFileSize.Row = r
        grdDeptFileSize.Col = c
        grdDeptFileSize.Text = t
    End Sub

    Private Sub frmDeptFileSize_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetGrid(2, 6)
        GridDisp(0, 0, "Departments:")
        GridDisp(0, 1, "No. Students")
        GridDisp(0, 2, "Module")
        GridDisp(0, 3, "Size")
        GridDisp(0, 4, "Module Average")
        GridDisp(0, 5, "Dept. Rating")
    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get number od departments/modules/weeks
        nDepts = CInt(InputBox("How many departments are you recording?"))
        nMod = CInt(InputBox("How many modules are there in each department?"))
        nWeek = CInt(InputBox("How many weeks are in each module?"))

        SetGrid(nDepts + 1, nMod + nMod + 4)

        'Resize arrays
        ReDim Departments(nDepts)

        Dim d As Integer
        For d = 1 To nDepts
            ReDim Departments(d).Modules(nMod)
        Next

        'Det up display
        Dim m As Integer
        For m = 1 To nMod
            GridDisp(0, m + 1, "Module Code" & m)
            GridDisp(0, nMod + 1 + m, "Size Module " & m)
        Next

        GridDisp(0, nMod + nMod + 2, "Dept. Avg.")
        GridDisp(0, nMod + nMod + 3, "Dept Rating")

    End Sub

    Private Sub btnDept_Click(sender As Object, e As EventArgs) Handles btnDept.Click

        Dim d As Integer
        Dim m As Integer

        For d = 1 To nDepts

            'Get name/no students of each dept and disp
            Departments(d).Name = InputBox("What is the name of department " & d)
            Departments(d).nStudents = CInt(InputBox("How many students are in department " & d))
            GridDisp(d, 0, Departments(d).Name)
            GridDisp(d, 1, CStr(Departments(d).nStudents))

            For m = 1 To nMod

                'Get code of each mod per dept and disp
                Departments(d).Modules(m).Code = CStr(InputBox("What is the code of module " & m & " in the " & Departments(d).Name & " Department"))
                GridDisp(d, m + 1, Departments(d).Modules(m).Code)

            Next

        Next

    End Sub

    Private Sub btnCaptData_Click(sender As Object, e As EventArgs) Handles btnCaptData.Click

        Dim d As Integer
        Dim m As Integer
        Dim w As Integer

        For d = 1 To nDepts

            'Initialize total in dept
            Departments(d).DeptTotSize = 0

            For m = 1 To nMod

                'Initialize total in mod
                Departments(d).Modules(m).ModTotSize = 0

                For w = 1 To nWeek

                    'Get weekly file size and add to mod total and disp total
                    Departments(d).Modules(m).WeekSize = CDbl(InputBox("What is the file size in week " & w & " for " & Departments(d).Modules(m).Code))
                    Departments(d).Modules(m).ModTotSize += Departments(d).Modules(m).WeekSize
                    GridDisp(d, m + nMod + 1, Format(Departments(d).Modules(m).ModTotSize, "0.0000"))

                Next

                'Calc dept total
                Departments(d).DeptTotSize += Departments(d).Modules(m).ModTotSize

            Next

        Next

    End Sub

    Private Sub btnAvg_Click(sender As Object, e As EventArgs) Handles btnAvg.Click

        Dim d As Integer

        For d = 1 To nDepts

            'Calc avg per dept
            Departments(d).ModAvg = Departments(d).DeptTotSize / nMod
            GridDisp(d, nMod + nMod + 2, Format(Departments(d).ModAvg, "0.0000"))

        Next

    End Sub

    'Function to convert to Gigs
    Private Function ConvertG(ByRef size As Double) As Double
        Return size / 1000
    End Function

    Private Sub btnRate_Click(sender As Object, e As EventArgs) Handles btnRate.Click

        Dim d As Integer
        Dim s As Double
        Dim r As Integer

        For d = 1 To nDepts

            'Convert avg using function
            s = ConvertG(Departments(d).ModAvg)

            'Det rating of new avg
            If s >= 0 And s < 0.75 Then
                r = 1
            End If

            If s >= 0.75 And s < 2.5 Then
                r = 2
            End If

            If s >= 2.5 Then
                r = 3
            End If

            'Dsiaplay ratings
            Departments(d).DeptRate = CStr(r)
            GridDisp(d, nMod + nMod + 3, CStr(r))

        Next

    End Sub

    Private Sub btnHigh_Click(sender As Object, e As EventArgs) Handles btnHigh.Click

        Dim MaxRate As Double
        Dim Max As Integer
        Dim d As Integer

        'Make dept 1 the initial max
        Max = 1
        MaxRate = Departments(1).ModAvg

        'Det new max dept
        For d = 2 To nDepts
            If MaxRate < Departments(d).ModAvg Then
                MaxRate = Departments(d).ModAvg
                Max = d
            End If
        Next

        'Recall max name/rate and disp on txtbox
        txtHighDeptName.Text = Departments(Max).Name
        txtHighModRate.Text = Departments(Max).DeptRate

    End Sub

End Class