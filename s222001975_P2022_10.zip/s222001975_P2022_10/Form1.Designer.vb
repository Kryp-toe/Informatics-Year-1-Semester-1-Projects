﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDeptFileSize
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnHigh = New System.Windows.Forms.Button()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnDept = New System.Windows.Forms.Button()
        Me.btnCaptData = New System.Windows.Forms.Button()
        Me.btnAvg = New System.Windows.Forms.Button()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.grdDeptFileSize = New UJGrid.UJGrid()
        Me.txtHighDeptName = New System.Windows.Forms.TextBox()
        Me.txtHighModRate = New System.Windows.Forms.TextBox()
        Me.lblHigh = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblRate = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnHigh
        '
        Me.btnHigh.Location = New System.Drawing.Point(487, 385)
        Me.btnHigh.Name = "btnHigh"
        Me.btnHigh.Size = New System.Drawing.Size(149, 41)
        Me.btnHigh.TabIndex = 0
        Me.btnHigh.Text = "Calculate"
        Me.btnHigh.UseVisualStyleBackColor = True
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(18, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(149, 41)
        Me.btnInitial.TabIndex = 1
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnDept
        '
        Me.btnDept.Location = New System.Drawing.Point(173, 12)
        Me.btnDept.Name = "btnDept"
        Me.btnDept.Size = New System.Drawing.Size(149, 41)
        Me.btnDept.TabIndex = 2
        Me.btnDept.Text = "Departments"
        Me.btnDept.UseVisualStyleBackColor = True
        '
        'btnCaptData
        '
        Me.btnCaptData.Location = New System.Drawing.Point(328, 12)
        Me.btnCaptData.Name = "btnCaptData"
        Me.btnCaptData.Size = New System.Drawing.Size(149, 41)
        Me.btnCaptData.TabIndex = 3
        Me.btnCaptData.Text = "Capture Data"
        Me.btnCaptData.UseVisualStyleBackColor = True
        '
        'btnAvg
        '
        Me.btnAvg.Location = New System.Drawing.Point(483, 12)
        Me.btnAvg.Name = "btnAvg"
        Me.btnAvg.Size = New System.Drawing.Size(149, 41)
        Me.btnAvg.TabIndex = 5
        Me.btnAvg.Text = "Calculate Average"
        Me.btnAvg.UseVisualStyleBackColor = True
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(638, 12)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(149, 41)
        Me.btnRate.TabIndex = 6
        Me.btnRate.Text = "Ratings"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'grdDeptFileSize
        '
        Me.grdDeptFileSize.Cols = 8
        Me.grdDeptFileSize.FixedCols = 0
        Me.grdDeptFileSize.FixedRows = 1
        Me.grdDeptFileSize.Location = New System.Drawing.Point(12, 59)
        Me.grdDeptFileSize.Name = "grdDeptFileSize"
        Me.grdDeptFileSize.Rows = 1
        Me.grdDeptFileSize.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdDeptFileSize.Size = New System.Drawing.Size(776, 291)
        Me.grdDeptFileSize.TabIndex = 7
        '
        'txtHighDeptName
        '
        Me.txtHighDeptName.Location = New System.Drawing.Point(209, 396)
        Me.txtHighDeptName.Name = "txtHighDeptName"
        Me.txtHighDeptName.Size = New System.Drawing.Size(133, 20)
        Me.txtHighDeptName.TabIndex = 8
        '
        'txtHighModRate
        '
        Me.txtHighModRate.Location = New System.Drawing.Point(348, 396)
        Me.txtHighModRate.Name = "txtHighModRate"
        Me.txtHighModRate.Size = New System.Drawing.Size(133, 20)
        Me.txtHighModRate.TabIndex = 9
        '
        'lblHigh
        '
        Me.lblHigh.AutoSize = True
        Me.lblHigh.Location = New System.Drawing.Point(5, 399)
        Me.lblHigh.Name = "lblHigh"
        Me.lblHigh.Size = New System.Drawing.Size(193, 13)
        Me.lblHigh.TabIndex = 10
        Me.lblHigh.Text = "Highest Module Average in Department"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(206, 380)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(35, 13)
        Me.lblName.TabIndex = 11
        Me.lblName.Text = "Name"
        '
        'lblRate
        '
        Me.lblRate.AutoSize = True
        Me.lblRate.Location = New System.Drawing.Point(345, 380)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(38, 13)
        Me.lblRate.TabIndex = 12
        Me.lblRate.Text = "Rating"
        '
        'frmDeptFileSize
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblRate)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblHigh)
        Me.Controls.Add(Me.txtHighModRate)
        Me.Controls.Add(Me.txtHighDeptName)
        Me.Controls.Add(Me.grdDeptFileSize)
        Me.Controls.Add(Me.btnRate)
        Me.Controls.Add(Me.btnAvg)
        Me.Controls.Add(Me.btnCaptData)
        Me.Controls.Add(Me.btnDept)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.btnHigh)
        Me.Name = "frmDeptFileSize"
        Me.Text = "Department File Size on BB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnHigh As Button
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnDept As Button
    Friend WithEvents btnCaptData As Button
    Friend WithEvents btnAvg As Button
    Friend WithEvents btnRate As Button
    Friend WithEvents grdDeptFileSize As UJGrid.UJGrid
    Friend WithEvents txtHighDeptName As TextBox
    Friend WithEvents txtHighModRate As TextBox
    Friend WithEvents lblHigh As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblRate As Label
End Class
