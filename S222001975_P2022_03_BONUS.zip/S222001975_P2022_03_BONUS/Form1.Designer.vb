﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPCMResultsBonus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNumPrac = New System.Windows.Forms.Label()
        Me.txtNumPrac = New System.Windows.Forms.TextBox()
        Me.btnAddMark = New System.Windows.Forms.Button()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.btnSetNumPrac = New System.Windows.Forms.Button()
        Me.btnResult = New System.Windows.Forms.Button()
        Me.txtSemTst = New System.Windows.Forms.TextBox()
        Me.txtPCM = New System.Windows.Forms.TextBox()
        Me.txtPracMark = New System.Windows.Forms.TextBox()
        Me.lblPracCompTtl = New System.Windows.Forms.Label()
        Me.lblTstM2 = New System.Windows.Forms.Label()
        Me.lblPracMs = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblNumPrac
        '
        Me.lblNumPrac.AutoSize = True
        Me.lblNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblNumPrac.Location = New System.Drawing.Point(46, 34)
        Me.lblNumPrac.Name = "lblNumPrac"
        Me.lblNumPrac.Size = New System.Drawing.Size(105, 13)
        Me.lblNumPrac.TabIndex = 38
        Me.lblNumPrac.Text = "Number of Practicals"
        '
        'txtNumPrac
        '
        Me.txtNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtNumPrac.Location = New System.Drawing.Point(170, 27)
        Me.txtNumPrac.Name = "txtNumPrac"
        Me.txtNumPrac.Size = New System.Drawing.Size(79, 20)
        Me.txtNumPrac.TabIndex = 37
        '
        'btnAddMark
        '
        Me.btnAddMark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnAddMark.Location = New System.Drawing.Point(286, 55)
        Me.btnAddMark.Name = "btnAddMark"
        Me.btnAddMark.Size = New System.Drawing.Size(141, 26)
        Me.btnAddMark.TabIndex = 36
        Me.btnAddMark.Text = "Add Practical Mark"
        Me.btnAddMark.UseVisualStyleBackColor = True
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblResult.Location = New System.Drawing.Point(114, 249)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(37, 13)
        Me.lblResult.TabIndex = 35
        Me.lblResult.Text = "Result"
        '
        'txtResult
        '
        Me.txtResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtResult.Location = New System.Drawing.Point(170, 246)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.Size = New System.Drawing.Size(186, 20)
        Me.txtResult.TabIndex = 34
        '
        'btnSetNumPrac
        '
        Me.btnSetNumPrac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnSetNumPrac.Location = New System.Drawing.Point(286, 23)
        Me.btnSetNumPrac.Name = "btnSetNumPrac"
        Me.btnSetNumPrac.Size = New System.Drawing.Size(141, 26)
        Me.btnSetNumPrac.TabIndex = 33
        Me.btnSetNumPrac.Text = "Set Up Number"
        Me.btnSetNumPrac.UseVisualStyleBackColor = True
        '
        'btnResult
        '
        Me.btnResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnResult.Location = New System.Drawing.Point(170, 144)
        Me.btnResult.Name = "btnResult"
        Me.btnResult.Size = New System.Drawing.Size(116, 24)
        Me.btnResult.TabIndex = 32
        Me.btnResult.Text = "Result"
        Me.btnResult.UseVisualStyleBackColor = True
        '
        'txtSemTst
        '
        Me.txtSemTst.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtSemTst.Location = New System.Drawing.Point(170, 97)
        Me.txtSemTst.Name = "txtSemTst"
        Me.txtSemTst.Size = New System.Drawing.Size(79, 20)
        Me.txtSemTst.TabIndex = 31
        '
        'txtPCM
        '
        Me.txtPCM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtPCM.Location = New System.Drawing.Point(170, 194)
        Me.txtPCM.Name = "txtPCM"
        Me.txtPCM.ReadOnly = True
        Me.txtPCM.Size = New System.Drawing.Size(186, 20)
        Me.txtPCM.TabIndex = 30
        '
        'txtPracMark
        '
        Me.txtPracMark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtPracMark.Location = New System.Drawing.Point(170, 61)
        Me.txtPracMark.Name = "txtPracMark"
        Me.txtPracMark.Size = New System.Drawing.Size(79, 20)
        Me.txtPracMark.TabIndex = 29
        '
        'lblPracCompTtl
        '
        Me.lblPracCompTtl.AutoSize = True
        Me.lblPracCompTtl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblPracCompTtl.Location = New System.Drawing.Point(19, 197)
        Me.lblPracCompTtl.Name = "lblPracCompTtl"
        Me.lblPracCompTtl.Size = New System.Drawing.Size(132, 13)
        Me.lblPracCompTtl.TabIndex = 28
        Me.lblPracCompTtl.Text = "Practical Component Total"
        '
        'lblTstM2
        '
        Me.lblTstM2.AutoSize = True
        Me.lblTstM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblTstM2.Location = New System.Drawing.Point(67, 104)
        Me.lblTstM2.Name = "lblTstM2"
        Me.lblTstM2.Size = New System.Drawing.Size(84, 13)
        Me.lblTstM2.TabIndex = 27
        Me.lblTstM2.Text = "Semester Test 2"
        '
        'lblPracMs
        '
        Me.lblPracMs.AutoSize = True
        Me.lblPracMs.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblPracMs.Location = New System.Drawing.Point(71, 68)
        Me.lblPracMs.Name = "lblPracMs"
        Me.lblPracMs.Size = New System.Drawing.Size(80, 13)
        Me.lblPracMs.TabIndex = 26
        Me.lblPracMs.Text = "Pracrical Marks"
        '
        'frmPCMResultsBonus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(467, 297)
        Me.Controls.Add(Me.lblNumPrac)
        Me.Controls.Add(Me.txtNumPrac)
        Me.Controls.Add(Me.btnAddMark)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.btnSetNumPrac)
        Me.Controls.Add(Me.btnResult)
        Me.Controls.Add(Me.txtSemTst)
        Me.Controls.Add(Me.txtPCM)
        Me.Controls.Add(Me.txtPracMark)
        Me.Controls.Add(Me.lblPracCompTtl)
        Me.Controls.Add(Me.lblTstM2)
        Me.Controls.Add(Me.lblPracMs)
        Me.Name = "frmPCMResultsBonus"
        Me.Text = "PCM Results Bonus"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNumPrac As Label
    Friend WithEvents txtNumPrac As TextBox
    Friend WithEvents btnAddMark As Button
    Friend WithEvents lblResult As Label
    Friend WithEvents txtResult As TextBox
    Friend WithEvents btnSetNumPrac As Button
    Friend WithEvents btnResult As Button
    Friend WithEvents txtSemTst As TextBox
    Friend WithEvents txtPCM As TextBox
    Friend WithEvents txtPracMark As TextBox
    Friend WithEvents lblPracCompTtl As Label
    Friend WithEvents lblTstM2 As Label
    Friend WithEvents lblPracMs As Label
End Class
