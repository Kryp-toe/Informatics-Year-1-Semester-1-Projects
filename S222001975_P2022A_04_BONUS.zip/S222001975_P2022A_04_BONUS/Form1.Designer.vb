﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAllowBONUS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdAllowance = New UJGrid.UJGrid()
        Me.btnInitialize = New System.Windows.Forms.Button()
        Me.btnWith = New System.Windows.Forms.Button()
        Me.btnDep = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdAllowance
        '
        Me.grdAllowance.Cols = 3
        Me.grdAllowance.FixedCols = 0
        Me.grdAllowance.FixedRows = 1
        Me.grdAllowance.Location = New System.Drawing.Point(156, 59)
        Me.grdAllowance.Name = "grdAllowance"
        Me.grdAllowance.Rows = 12
        Me.grdAllowance.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdAllowance.Size = New System.Drawing.Size(306, 293)
        Me.grdAllowance.TabIndex = 0
        '
        'btnInitialize
        '
        Me.btnInitialize.Location = New System.Drawing.Point(156, 12)
        Me.btnInitialize.Name = "btnInitialize"
        Me.btnInitialize.Size = New System.Drawing.Size(91, 41)
        Me.btnInitialize.TabIndex = 1
        Me.btnInitialize.Text = "Initialize"
        Me.btnInitialize.UseVisualStyleBackColor = True
        '
        'btnWith
        '
        Me.btnWith.Location = New System.Drawing.Point(253, 12)
        Me.btnWith.Name = "btnWith"
        Me.btnWith.Size = New System.Drawing.Size(99, 41)
        Me.btnWith.TabIndex = 2
        Me.btnWith.Text = "Withdraw"
        Me.btnWith.UseVisualStyleBackColor = True
        '
        'btnDep
        '
        Me.btnDep.Location = New System.Drawing.Point(358, 12)
        Me.btnDep.Name = "btnDep"
        Me.btnDep.Size = New System.Drawing.Size(104, 41)
        Me.btnDep.TabIndex = 3
        Me.btnDep.Text = "Deposit"
        Me.btnDep.UseVisualStyleBackColor = True
        '
        'frmAllowBONUS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnDep)
        Me.Controls.Add(Me.btnWith)
        Me.Controls.Add(Me.btnInitialize)
        Me.Controls.Add(Me.grdAllowance)
        Me.Name = "frmAllowBONUS"
        Me.Text = "Allowance (BONUS)"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdAllowance As UJGrid.UJGrid
    Friend WithEvents btnInitialize As Button
    Friend WithEvents btnWith As Button
    Friend WithEvents btnDep As Button
End Class
