﻿' ****************************************************************************
' Surname, Initials: MAyet, AA
' Student Number: 222001975
' Practical: P2022A-04
' Class name: frmAllowBONUS
' ****************************************************************************
Option Strict On
Option Explicit On
Public Class frmAllowBONUS

    Private OpenBal As Double
    Private EndBal As Double
    Private Withdraw As Double
    Private TtlWithdraw As Double
    Private Deposit As Double
    Private TtlDeposit As Double
    Private NumTransDep As Integer
    Private NumTransWith As Integer
    Private CountDep As Integer
    Private CountWith As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnInitialize.Click

        OpenBal = CDbl(InputBox("Please neter your balance in the begining"))

        EndBal = 0
        Withdraw = 0
        TtlDeposit = 0
        Deposit = 0
        TtlDeposit = 0
        NumTransDep = 0
        NumTransWith = 0
        CountWith = 0
        CountDep = 0

        grdAllowance.Cols = 3

        grdAllowance.Row = 0

        grdAllowance.Col = 0
        grdAllowance.Text = "Balance"

        grdAllowance.Col = 1
        grdAllowance.Text = "Withdrawls(-)"

        grdAllowance.Col = 2
        grdAllowance.Text = "Deposits(+)"

        grdAllowance.Row = 1

        grdAllowance.Col = 0
        grdAllowance.Text = "R" & CStr(OpenBal)

        grdAllowance.Row = CountWith
        grdAllowance.Col = 1

        grdAllowance.Row = CountDep
        grdAllowance.Col = 2

    End Sub

    Private Sub btnWith_Click(sender As Object, e As EventArgs) Handles btnWith.Click

        NumTransWith = CInt(InputBox("How many withdrawls would you like to make"))

        grdAllowance.Col = 1
        grdAllowance.Rows = NumTransWith + 2

        While NumTransWith > CountWith
            Withdraw = CDbl(InputBox("Insert Withdrawl amount:"))
            CountWith = CountWith + 1

            grdAllowance.Row = CountWith
            grdAllowance.Col = 1
            grdAllowance.Text = "- R" & CStr(Withdraw)

            TtlWithdraw = Withdraw + TtlWithdraw

            EndBal = OpenBal + TtlDeposit - TtlWithdraw

            If EndBal <= 50 Then

                MsgBox("Warning your balance is R" & CStr(EndBal))

                If EndBal <= 0 Then
                    MsgBox("No More Withdrawls allowed balance is R" & CStr(EndBal))
                End If

            End If

        End While

        If NumTransWith = CountWith Then

            EndBal = OpenBal + TtlDeposit - TtlWithdraw

            MsgBox("All Withdrawls complete." & " Balance: R" & CStr(EndBal))

            grdAllowance.Row = CountDep + 1
            grdAllowance.Col = 2
            grdAllowance.Text = "+ R" & CStr(TtlDeposit)

            grdAllowance.Row = CountWith + 1
            grdAllowance.Col = 1
            grdAllowance.Text = "- R" & CStr(TtlWithdraw)

            grdAllowance.Col = 0
            grdAllowance.Text = "R" & CStr(EndBal)

        End If

    End Sub

    Private Sub btnDep_Click(sender As Object, e As EventArgs) Handles btnDep.Click

        NumTransDep = CInt(InputBox("How many deposits would you like to make"))

        grdAllowance.Col = 2
        grdAllowance.Rows = NumTransDep + 2

        While NumTransDep > CountDep

            Deposit = CDbl(InputBox("Insert Deposit amount:"))
            CountDep = CountDep + 1

            grdAllowance.Row = CountDep
            grdAllowance.Col = 2
            grdAllowance.Text = "+ R" & CStr(Deposit)

            TtlDeposit = Deposit + TtlDeposit

            EndBal = OpenBal + TtlDeposit - TtlWithdraw

            If EndBal <= 50 Then

                MsgBox("Warning your balance is R" & CStr(EndBal))

                If EndBal <= 0 Then
                    MsgBox("No More Withdrawls allowed balance is R" & CStr(EndBal))
                End If

            End If

        End While

        If NumTransWith = CountWith Then

            EndBal = OpenBal + TtlDeposit - TtlWithdraw

            MsgBox("All Deposits complete." & " Balance: R" & CStr(EndBal))

            grdAllowance.Row = CountDep + 1
            grdAllowance.Col = 2
            grdAllowance.Text = "+ R" & CStr(TtlDeposit)

            grdAllowance.Row = CountWith + 1
            grdAllowance.Col = 1
            grdAllowance.Text = "- R" & CStr(TtlWithdraw)

            grdAllowance.Col = 0
            grdAllowance.Text = "R" & CStr(EndBal)

        End If

    End Sub
End Class
