﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEastSaleTrack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdEastSaleTrack = New UJGrid.UJGrid()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnCaptData = New System.Windows.Forms.Button()
        Me.btnEditData = New System.Windows.Forms.Button()
        Me.txtHigh4 = New System.Windows.Forms.TextBox()
        Me.txtHigh3 = New System.Windows.Forms.TextBox()
        Me.txtHigh2 = New System.Windows.Forms.TextBox()
        Me.txtHigh1 = New System.Windows.Forms.TextBox()
        Me.txtTotalEggs = New System.Windows.Forms.TextBox()
        Me.lblTotEggSold = New System.Windows.Forms.Label()
        Me.lblHighStore1 = New System.Windows.Forms.Label()
        Me.lblHighStore2 = New System.Windows.Forms.Label()
        Me.btnHighStore3 = New System.Windows.Forms.Label()
        Me.lblHighStore4 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnHigh = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdEastSaleTrack
        '
        Me.grdEastSaleTrack.Cols = 5
        Me.grdEastSaleTrack.FixedCols = 1
        Me.grdEastSaleTrack.FixedRows = 1
        Me.grdEastSaleTrack.Location = New System.Drawing.Point(12, 61)
        Me.grdEastSaleTrack.Name = "grdEastSaleTrack"
        Me.grdEastSaleTrack.Rows = 6
        Me.grdEastSaleTrack.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdEastSaleTrack.Size = New System.Drawing.Size(505, 148)
        Me.grdEastSaleTrack.TabIndex = 0
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(96, 43)
        Me.btnInitial.TabIndex = 1
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnCaptData
        '
        Me.btnCaptData.Location = New System.Drawing.Point(114, 12)
        Me.btnCaptData.Name = "btnCaptData"
        Me.btnCaptData.Size = New System.Drawing.Size(98, 43)
        Me.btnCaptData.TabIndex = 2
        Me.btnCaptData.Text = "Capture Data"
        Me.btnCaptData.UseVisualStyleBackColor = True
        '
        'btnEditData
        '
        Me.btnEditData.Location = New System.Drawing.Point(218, 12)
        Me.btnEditData.Name = "btnEditData"
        Me.btnEditData.Size = New System.Drawing.Size(97, 43)
        Me.btnEditData.TabIndex = 3
        Me.btnEditData.Text = "Edit Data"
        Me.btnEditData.UseVisualStyleBackColor = True
        '
        'txtHigh4
        '
        Me.txtHigh4.Location = New System.Drawing.Point(112, 334)
        Me.txtHigh4.Name = "txtHigh4"
        Me.txtHigh4.Size = New System.Drawing.Size(100, 20)
        Me.txtHigh4.TabIndex = 4
        '
        'txtHigh3
        '
        Me.txtHigh3.Location = New System.Drawing.Point(112, 308)
        Me.txtHigh3.Name = "txtHigh3"
        Me.txtHigh3.Size = New System.Drawing.Size(100, 20)
        Me.txtHigh3.TabIndex = 5
        '
        'txtHigh2
        '
        Me.txtHigh2.Location = New System.Drawing.Point(112, 282)
        Me.txtHigh2.Name = "txtHigh2"
        Me.txtHigh2.Size = New System.Drawing.Size(100, 20)
        Me.txtHigh2.TabIndex = 6
        '
        'txtHigh1
        '
        Me.txtHigh1.Location = New System.Drawing.Point(112, 256)
        Me.txtHigh1.Name = "txtHigh1"
        Me.txtHigh1.Size = New System.Drawing.Size(100, 20)
        Me.txtHigh1.TabIndex = 7
        '
        'txtTotalEggs
        '
        Me.txtTotalEggs.Location = New System.Drawing.Point(112, 230)
        Me.txtTotalEggs.Name = "txtTotalEggs"
        Me.txtTotalEggs.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalEggs.TabIndex = 8
        '
        'lblTotEggSold
        '
        Me.lblTotEggSold.AutoSize = True
        Me.lblTotEggSold.Location = New System.Drawing.Point(12, 233)
        Me.lblTotEggSold.Name = "lblTotEggSold"
        Me.lblTotEggSold.Size = New System.Drawing.Size(82, 13)
        Me.lblTotEggSold.TabIndex = 9
        Me.lblTotEggSold.Text = "Total Eggs Sold"
        '
        'lblHighStore1
        '
        Me.lblHighStore1.AutoSize = True
        Me.lblHighStore1.Location = New System.Drawing.Point(12, 259)
        Me.lblHighStore1.Name = "lblHighStore1"
        Me.lblHighStore1.Size = New System.Drawing.Size(87, 13)
        Me.lblHighStore1.TabIndex = 10
        Me.lblHighStore1.Text = "Highest on day 1"
        '
        'lblHighStore2
        '
        Me.lblHighStore2.AutoSize = True
        Me.lblHighStore2.Location = New System.Drawing.Point(12, 285)
        Me.lblHighStore2.Name = "lblHighStore2"
        Me.lblHighStore2.Size = New System.Drawing.Size(87, 13)
        Me.lblHighStore2.TabIndex = 11
        Me.lblHighStore2.Text = "Highest on day 2"
        '
        'btnHighStore3
        '
        Me.btnHighStore3.AutoSize = True
        Me.btnHighStore3.Location = New System.Drawing.Point(12, 311)
        Me.btnHighStore3.Name = "btnHighStore3"
        Me.btnHighStore3.Size = New System.Drawing.Size(87, 13)
        Me.btnHighStore3.TabIndex = 12
        Me.btnHighStore3.Text = "Highest on day 3"
        '
        'lblHighStore4
        '
        Me.lblHighStore4.AutoSize = True
        Me.lblHighStore4.Location = New System.Drawing.Point(12, 337)
        Me.lblHighStore4.Name = "lblHighStore4"
        Me.lblHighStore4.Size = New System.Drawing.Size(87, 13)
        Me.lblHighStore4.TabIndex = 13
        Me.lblHighStore4.Text = "Highest on day 4"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(322, 12)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(95, 43)
        Me.btnCalc.TabIndex = 14
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnHigh
        '
        Me.btnHigh.Location = New System.Drawing.Point(423, 12)
        Me.btnHigh.Name = "btnHigh"
        Me.btnHigh.Size = New System.Drawing.Size(94, 43)
        Me.btnHigh.TabIndex = 15
        Me.btnHigh.Text = "Highest"
        Me.btnHigh.UseVisualStyleBackColor = True
        '
        'frmEastSaleTrack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(542, 391)
        Me.Controls.Add(Me.btnHigh)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblHighStore4)
        Me.Controls.Add(Me.btnHighStore3)
        Me.Controls.Add(Me.lblHighStore2)
        Me.Controls.Add(Me.lblHighStore1)
        Me.Controls.Add(Me.lblTotEggSold)
        Me.Controls.Add(Me.txtTotalEggs)
        Me.Controls.Add(Me.txtHigh1)
        Me.Controls.Add(Me.txtHigh2)
        Me.Controls.Add(Me.txtHigh3)
        Me.Controls.Add(Me.txtHigh4)
        Me.Controls.Add(Me.btnEditData)
        Me.Controls.Add(Me.btnCaptData)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.grdEastSaleTrack)
        Me.Name = "frmEastSaleTrack"
        Me.Text = "Easter Sales Tracker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grdEastSaleTrack As UJGrid.UJGrid
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnCaptData As Button
    Friend WithEvents btnEditData As Button
    Friend WithEvents txtHigh4 As TextBox
    Friend WithEvents txtHigh3 As TextBox
    Friend WithEvents txtHigh2 As TextBox
    Friend WithEvents txtHigh1 As TextBox
    Friend WithEvents txtTotalEggs As TextBox
    Friend WithEvents lblTotEggSold As Label
    Friend WithEvents lblHighStore1 As Label
    Friend WithEvents lblHighStore2 As Label
    Friend WithEvents btnHighStore3 As Label
    Friend WithEvents lblHighStore4 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnHigh As Button
End Class
