﻿' ****************************************************************************
' Surname, Initials: MAYET, AA
' Student Number: 222001975
' Practical: P2022A-07
' Class name: frmEastSaleTrack
' ****************************************************************************
Option Explicit On
Option Strict On
Option Infer Off

Public Class frmEastSaleTrack

    'Declare variables
    Private D1S1, D1S2, D1S3 As Integer
    Private D2S1, D2S2, D2S3 As Integer
    Private D3S1, D3S2, D3S3 As Integer
    Private D4S1, D4S2, D4S3 As Integer
    Private Day, Store, Number As Integer
    Private Numb, Total As Integer
    Private TS1, TS2, TS3 As Integer
    Private AD1, AD2, AD3, AD4 As Double
    Private TD1, TD2, TD3, TD4 As Integer

    'Subroutine for grid display
    Private Sub GridDisp(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdEastSaleTrack.Col = c
        grdEastSaleTrack.Row = r
        grdEastSaleTrack.Text = t
    End Sub

    'Subroutine for grid config
    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdEastSaleTrack.Rows = R
        grdEastSaleTrack.Cols = C
    End Sub

    'Display when the form loads
    Private Sub frmEastSaleTrack_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(5, 6)
        GridDisp(1, 0, "Store 1")
        GridDisp(2, 0, "Store 2")
        GridDisp(3, 0, "Store 3")
        GridDisp(4, 0, "Average")
        GridDisp(0, 1, "Day 1")
        GridDisp(0, 2, "Day 2")
        GridDisp(0, 3, "Day 3")
        GridDisp(0, 4, "Day 4")
        GridDisp(0, 5, "Total")

    End Sub

    'Function for getting number of eggs and placing them in variables
    Private Function PlaceVar(ByVal d As Integer, ByVal s As Integer, ByVal n As Integer) As Integer

        'Day 1
        If d = 1 Then

            If s = 1 Then
                D1S1 = n
                Return D1S1
            End If

            If s = 2 Then
                D1S2 = n
                Return D1S2
            End If

            If s = 3 Then
                D1S3 = n
                Return D1S3
            End If

        End If

        'Day 2
        If d = 2 Then

            If s = 1 Then
                D2S1 = n
                Return D2S1
            End If

            If s = 2 Then
                D2S2 = n
                Return D2S2
            End If

            If s = 3 Then
                D2S3 = n
                Return D2S3
            End If

        End If

        'Day 3
        If d = 3 Then

            If s = 1 Then
                D3S1 = n
                Return D3S1
            End If

            If s = 2 Then
                D3S2 = n
                Return D3S2
            End If

            If s = 3 Then
                D3S3 = n
                Return D3S3
            End If

        End If

        'Day 4
        If d = 4 Then

            If s = 1 Then
                D4S1 = n
                Return D4S1
            End If

            If s = 2 Then
                D4S2 = n
                Return D4S2
            End If

            If s = 3 Then
                D4S3 = n
                Return D4S3
            End If

        End If

        'If an invalid day is entered then warn the user
        If d > 4 Then
            MsgBox("ERROR!! There are only 4 days try again.")
        End If

        If s > 3 Then
            MsgBox("ERROR!! There are only 3 stores try again")
        End If

    End Function

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Initialize all variables
        D1S1 = 0
        D1S2 = 0
        D1S3 = 0
        D2S1 = 0
        D2S2 = 0
        D2S3 = 0
        D3S1 = 0
        D3S2 = 0
        D3S3 = 0
        D4S1 = 0
        D4S2 = 0
        D4S3 = 0
        Day = 0
        Store = 0
        Number = 0
        Numb = 0
        Total = 0
        TS1 = 0
        TS2 = 0
        TS3 = 0
        AD1 = 0
        AD2 = 0
        AD3 = 0
        AD4 = 0

        SetGrid(5, 6)

    End Sub

    Private Sub btnCaptData_Click(sender As Object, e As EventArgs) Handles btnCaptData.Click

        'Get day of sale and which store
        Day = CInt(InputBox("What day would you like to capture data for?"))
        Store = CInt(InputBox("Which store would you like to capture data for?"))

        'If a valid day or store is entered then place into variables
        If Day <= 4 And Store <= 3 Then

            'Get number of eggs
            Number = CInt(InputBox("How many eggs were sold on day " & Day & " in store " & Store))

            Numb = PlaceVar(Day, Store, Number)
            GridDisp(Store, Day, CStr(Numb))
        Else

            'If invalid day/store then warn user
            MsgBox("ERROR!! There are only 4 days and 3 stores try again.")

        End If

    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click

        'Get day/store 
        Day = CInt(InputBox("What day would you like to change?"))
        Store = CInt(InputBox("Which store would you like to change?"))

        'Run function if valid day/store is entered
        If Day <= 4 And Store <= 3 Then

            Number = CInt(InputBox("How many eggs were sold on day " & Day & " in store " & Store))

            Numb = PlaceVar(Day, Store, Number)
            GridDisp(Store, Day, CStr(Numb))
        Else

            'Warn user if invalid entry is made
            MsgBox("ERROR!! There are only 4 days and 3 stores try again.")

        End If

    End Sub

    Private Sub btnCalcTotal_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Calculate total for store 1
        TS1 = D1S1 + D2S1 + D3S1 + D4S1
        GridDisp(1, 5, CStr(TS1))

        'Store 2
        TS2 = D1S2 + D2S2 + D3S2 + D4S2
        GridDisp(2, 5, CStr(TS2))

        'Store 3
        TS3 = D1S3 + D2S3 + D3S3 + D4S3
        GridDisp(3, 5, CStr(TS3))

        'Calculate complete total
        Total = TS1 + TS2 + TS3
        txtTotalEggs.Text = CStr(Total)

        'Calculate total/avg for day 1
        TD1 = D1S1 + D1S2 + D1S3
        AD1 = TD1 / 3
        GridDisp(4, 1, CStr(AD1))

        'Day 2
        TD2 = D2S1 + D2S2 + D2S3
        AD2 = TD2 / 3
        GridDisp(4, 2, CStr(AD2))

        'Day 3
        TD3 = D3S1 + D3S2 + D3S3
        AD3 = TD3 / 3
        GridDisp(4, 3, CStr(AD3))

        'Day 4
        TD4 = D4S1 + D4S2 + D4S3
        AD4 = TD4 / 3
        GridDisp(4, 4, CStr(AD4))

    End Sub

    Private Sub btnHigh_Click(sender As Object, e As EventArgs) Handles btnHigh.Click

        'Calculate the highest on day 1
        If D1S1 > D1S2 And D1S1 > D1S3 Then
            txtHigh1.Text = "Store 1"
        End If

        If D1S2 > D1S1 And D1S2 > D1S3 Then
            txtHigh1.Text = "Store 2"
        End If

        If D1S3 > D1S2 And D1S3 > D1S1 Then
            txtHigh1.Text = "Store 3"
        End If

        'Day 2
        If D2S1 > D2S2 And D2S1 > D2S3 Then
            txtHigh2.Text = "Store 1"
        End If

        If D2S2 > D2S1 And D2S2 > D2S3 Then
            txtHigh2.Text = "Store 2"
        End If

        If D2S3 > D2S2 And D2S3 > D2S1 Then
            txtHigh2.Text = "Store 3"
        End If

        'Day 3
        If D3S1 > D3S2 And D3S1 > D3S3 Then
            txtHigh3.Text = "Store 1"
        End If

        If D3S2 > D3S1 And D3S2 > D3S3 Then
            txtHigh3.Text = "Store 2"
        End If

        If D3S3 > D3S2 And D3S3 > D3S1 Then
            txtHigh3.Text = "Store 3"
        End If

        'Day 4
        If D4S1 > D4S2 And D4S1 > D4S3 Then
            txtHigh4.Text = "Store 1"
        End If

        If D4S2 > D4S1 And D4S2 > D4S3 Then
            txtHigh4.Text = "Store 2"
        End If

        If D4S3 > D4S2 And D4S3 > D4S1 Then
            txtHigh4.Text = "Store 3"
        End If

    End Sub

End Class
