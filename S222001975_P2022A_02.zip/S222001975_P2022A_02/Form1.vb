﻿' ****************************************************************************
' Surname, Initials: Mayet,AA
' Student Number: 222001975
' Practical: P2022A-01
' Class name: frmPraMrkCalc
' ****************************************************************************

Option Strict On
Option Explicit On
Public Class frmPraMrkCalc

    'Declare all variables

    Private PracM1 As Double
    Private PracM2 As Double
    Private PracM3 As Double
    Private PracM4 As Double
    Private PracMks As Double
    Private PracMksPrc As Double
    Private TtlPracM As Double
    Private TstM2 As Double
    Private PracCompTtl As Double
    Private TtlTstM As Double

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Get Practical Assignment Marks from the user and put them into variables
        PracM1 = CDbl(txtPracM1.Text)
        PracM2 = CDbl(txtPracM2.Text)
        PracM3 = CDbl(txtPracM3.Text)
        PracM4 = CDbl(txtPracM4.Text)

        'Calculate the average Practical MArk of all assignments and put the answer in a variable
        PracMks = PracM1 + PracM2 + PracM3 + PracM4
        PracMksPrc = PracMks / 4

        'Multiply the average by 10/75 and put it into a variable (A)
        TtlPracM = PracMksPrc * 10 / 75

        'Get the Semester test 2 mark from the user and put it into a variable
        TstM2 = CDbl(txtTstM2.Text)

        'MUltiply the test mark by 65/75 and put it into a variable (B)
        TtlTstM = TstM2 * 65 / 75

        'Add part A and B to get the Practical Component Mark
        'Dosplay this to the user
        PracCompTtl = TtlTstM + TtlPracM
        txtPracCompTtl.Text = CStr(PracCompTtl)

    End Sub
End Class
