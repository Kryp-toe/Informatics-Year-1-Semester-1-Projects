﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPraMrkCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblPracMs = New System.Windows.Forms.Label()
        Me.lblTstM2 = New System.Windows.Forms.Label()
        Me.lblPracCompTtl = New System.Windows.Forms.Label()
        Me.txtPracM4 = New System.Windows.Forms.TextBox()
        Me.txtPracM1 = New System.Windows.Forms.TextBox()
        Me.txtPracM2 = New System.Windows.Forms.TextBox()
        Me.txtPracM3 = New System.Windows.Forms.TextBox()
        Me.txtPracCompTtl = New System.Windows.Forms.TextBox()
        Me.txtTstM2 = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblPracMs
        '
        Me.lblPracMs.AutoSize = True
        Me.lblPracMs.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblPracMs.Location = New System.Drawing.Point(12, 59)
        Me.lblPracMs.Name = "lblPracMs"
        Me.lblPracMs.Size = New System.Drawing.Size(146, 25)
        Me.lblPracMs.TabIndex = 0
        Me.lblPracMs.Text = "Pracrical Marks"
        '
        'lblTstM2
        '
        Me.lblTstM2.AutoSize = True
        Me.lblTstM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblTstM2.Location = New System.Drawing.Point(2, 130)
        Me.lblTstM2.Name = "lblTstM2"
        Me.lblTstM2.Size = New System.Drawing.Size(156, 25)
        Me.lblTstM2.TabIndex = 1
        Me.lblTstM2.Text = "Semester Test 2"
        '
        'lblPracCompTtl
        '
        Me.lblPracCompTtl.AutoSize = True
        Me.lblPracCompTtl.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblPracCompTtl.Location = New System.Drawing.Point(23, 269)
        Me.lblPracCompTtl.Name = "lblPracCompTtl"
        Me.lblPracCompTtl.Size = New System.Drawing.Size(135, 25)
        Me.lblPracCompTtl.TabIndex = 2
        Me.lblPracCompTtl.Text = "Practical Total"
        '
        'txtPracM4
        '
        Me.txtPracM4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPracM4.Location = New System.Drawing.Point(403, 56)
        Me.txtPracM4.Name = "txtPracM4"
        Me.txtPracM4.Size = New System.Drawing.Size(79, 30)
        Me.txtPracM4.TabIndex = 3
        '
        'txtPracM1
        '
        Me.txtPracM1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPracM1.Location = New System.Drawing.Point(233, 56)
        Me.txtPracM1.Name = "txtPracM1"
        Me.txtPracM1.Size = New System.Drawing.Size(79, 30)
        Me.txtPracM1.TabIndex = 4
        '
        'txtPracM2
        '
        Me.txtPracM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPracM2.Location = New System.Drawing.Point(318, 56)
        Me.txtPracM2.Name = "txtPracM2"
        Me.txtPracM2.Size = New System.Drawing.Size(79, 30)
        Me.txtPracM2.TabIndex = 5
        '
        'txtPracM3
        '
        Me.txtPracM3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPracM3.Location = New System.Drawing.Point(488, 56)
        Me.txtPracM3.Name = "txtPracM3"
        Me.txtPracM3.Size = New System.Drawing.Size(79, 30)
        Me.txtPracM3.TabIndex = 6
        '
        'txtPracCompTtl
        '
        Me.txtPracCompTtl.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPracCompTtl.Location = New System.Drawing.Point(233, 264)
        Me.txtPracCompTtl.Name = "txtPracCompTtl"
        Me.txtPracCompTtl.ReadOnly = True
        Me.txtPracCompTtl.Size = New System.Drawing.Size(107, 30)
        Me.txtPracCompTtl.TabIndex = 7
        '
        'txtTstM2
        '
        Me.txtTstM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtTstM2.Location = New System.Drawing.Point(233, 125)
        Me.txtTstM2.Name = "txtTstM2"
        Me.txtTstM2.Size = New System.Drawing.Size(79, 30)
        Me.txtTstM2.TabIndex = 8
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.btnCalc.Location = New System.Drawing.Point(202, 192)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(111, 34)
        Me.btnCalc.TabIndex = 9
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'frmPraMrkCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtTstM2)
        Me.Controls.Add(Me.txtPracCompTtl)
        Me.Controls.Add(Me.txtPracM3)
        Me.Controls.Add(Me.txtPracM2)
        Me.Controls.Add(Me.txtPracM1)
        Me.Controls.Add(Me.txtPracM4)
        Me.Controls.Add(Me.lblPracCompTtl)
        Me.Controls.Add(Me.lblTstM2)
        Me.Controls.Add(Me.lblPracMs)
        Me.Name = "frmPraMrkCalc"
        Me.Text = "Practical Mark Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPracMs As Label
    Friend WithEvents lblTstM2 As Label
    Friend WithEvents lblPracCompTtl As Label
    Friend WithEvents txtPracM4 As TextBox
    Friend WithEvents txtPracM1 As TextBox
    Friend WithEvents txtPracM2 As TextBox
    Friend WithEvents txtPracM3 As TextBox
    Friend WithEvents txtPracCompTtl As TextBox
    Friend WithEvents txtTstM2 As TextBox
    Friend WithEvents btnCalc As Button
End Class
