﻿' ****************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022A-04
' Class name: frmAllowTrack
' ****************************************************************************

Option Explicit On
Option Strict On

Public Class frmAllowTrack

    'Declare Variables
    Private OpenBal As Double
    Private EndBal As Double
    Private Withdraw As Double
    Private TtlWithdraw As Double
    Private Deposit As Double
    Private TtlDeposit As Double
    Private NumTransDep As Integer
    Private NumTransWith As Integer

    Private Sub btnInitialize_Click(sender As Object, e As EventArgs) Handles btnInitialize.Click

        'Get number inputs from user
        OpenBal = CDbl(InputBox("Please enter your Allowance:"))

        NumTransDep = 0
        NumTransWith = 0
        TtlDeposit = 0
        Deposit = 0
        TtlWithdraw = 0
        Withdraw = 0

        EndBal = OpenBal + TtlDeposit - TtlWithdraw
        txtBal.Text = CStr(EndBal)

    End Sub

    Private Sub btnWith_Click(sender As Object, e As EventArgs) Handles btnWith.Click

        NumTransWith = CInt(InputBox("Insert the number of Withdrawls you would like to make:"))

        'Only when number of transactions is above 0 then...
        'Same as deposits but with withdrawl
        While NumTransWith > 0

            NumTransWith = NumTransWith - 1
            Withdraw = CDbl(InputBox("Insert Withdrawl amount:"))
            TtlWithdraw = Withdraw + TtlWithdraw
            EndBal = OpenBal + TtlDeposit - TtlWithdraw
            txtBal.Text = CStr(EndBal)

            If EndBal <= 50 Then
                MsgBox("Warning your balance is R" & CStr(EndBal))
                txtBal.Text = CStr(EndBal)

                If EndBal <= 0 Then
                    MsgBox("No More Withdrawls allowed balance is R" & CStr(EndBal))
                    NumTransWith = 0
                    txtBal.Text = CStr(EndBal)
                End If

            Else
                MsgBox("Transaction complete." & " Balance: R" & CStr(EndBal))
                txtBal.Text = CStr(EndBal)
            End If

        End While

        'Warn the user when their balance equal or less than R50
        'Disallow the user from entering more deduction transactions after their balance Is less than Or equal to zero.

        If NumTransWith = 0 And NumTransDep = 0 Then

            MsgBox("All Withdrawls are complete." & " Balance: R" & CStr(EndBal))
            txtBal.Text = CStr(EndBal)

        End If

    End Sub

    Private Sub btnDeposit_Click_1(sender As Object, e As EventArgs) Handles btnDeposit.Click

        NumTransDep = CInt(InputBox("Insert the number of Deposits you would like to make:"))

        'Only when the number of transactions is above 0 then....
        While NumTransDep > 0

            'Get Amounts from user and reduce while loop
            Deposit = CDbl(InputBox("Insert Deposit amount:"))
            NumTransDep = NumTransDep - 1
            'Add amounts together
            TtlDeposit = Deposit + TtlDeposit
            EndBal = OpenBal + TtlDeposit - TtlWithdraw
            txtBal.Text = CStr(EndBal)

            'If balance is below 50 then warn user
            If EndBal <= 50 Then
                MsgBox("Warning your balance is R" & CStr(EndBal))

                'If balance is below 0 then do not allow withdrawls
                If EndBal <= 0 Then
                    MsgBox("No More Withdrawls allowed balance is R" & CStr(EndBal))
                    NumTransWith = 0
                    txtBal.Text = CStr(EndBal)
                End If

                'Else tell user balance
            Else
                MsgBox("Transaction complete." & " Balance: R" & CStr(EndBal))
                txtBal.Text = CStr(EndBal)
            End If

        End While

        'Warn the user when their balance equal or less than R50
        'Disallow the user from entering more deduction transactions after their balance Is less than Or equal to zero.

        If NumTransWith = 0 And NumTransDep = 0 Then

            MsgBox("All Deposits are complete." & " Balance: R" & CStr(EndBal))
            txtBal.Text = CStr(EndBal)

        End If

    End Sub
End Class
