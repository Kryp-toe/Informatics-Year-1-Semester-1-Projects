﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAllowTrack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnInitialize = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBal = New System.Windows.Forms.TextBox()
        Me.btnWith = New System.Windows.Forms.Button()
        Me.btnDeposit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnInitialize
        '
        Me.btnInitialize.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnInitialize.Location = New System.Drawing.Point(15, 29)
        Me.btnInitialize.Name = "btnInitialize"
        Me.btnInitialize.Size = New System.Drawing.Size(91, 74)
        Me.btnInitialize.TabIndex = 4
        Me.btnInitialize.Text = "Initialize"
        Me.btnInitialize.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 130)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Balance:"
        '
        'txtBal
        '
        Me.txtBal.Location = New System.Drawing.Point(67, 127)
        Me.txtBal.Name = "txtBal"
        Me.txtBal.ReadOnly = True
        Me.txtBal.Size = New System.Drawing.Size(100, 20)
        Me.txtBal.TabIndex = 6
        '
        'btnWith
        '
        Me.btnWith.Location = New System.Drawing.Point(112, 29)
        Me.btnWith.Name = "btnWith"
        Me.btnWith.Size = New System.Drawing.Size(88, 74)
        Me.btnWith.TabIndex = 7
        Me.btnWith.Text = "Withdraw"
        Me.btnWith.UseVisualStyleBackColor = True
        '
        'btnDeposit
        '
        Me.btnDeposit.Location = New System.Drawing.Point(206, 29)
        Me.btnDeposit.Name = "btnDeposit"
        Me.btnDeposit.Size = New System.Drawing.Size(90, 74)
        Me.btnDeposit.TabIndex = 8
        Me.btnDeposit.Text = "Deposit"
        Me.btnDeposit.UseVisualStyleBackColor = True
        '
        'frmAllowTrack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 171)
        Me.Controls.Add(Me.btnDeposit)
        Me.Controls.Add(Me.btnWith)
        Me.Controls.Add(Me.txtBal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnInitialize)
        Me.Name = "frmAllowTrack"
        Me.Text = "Allowance Tracker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnInitialize As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtBal As TextBox
    Friend WithEvents btnWith As Button
    Friend WithEvents btnDeposit As Button
End Class
